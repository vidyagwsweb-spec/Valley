# Valley Site Spark / tab controls preview patch

- Keeps the preview application ID `ai.valley.browser.preview` so it can be installed alongside the original app.
- In tab/bookmark overview mode, the left and right toolbar controls remain visible around the centered count pill. The left `+` opens New Tab / New Private Tab; the right `…` opens tab actions.
- Tab overview cards now attempt to draw a small WebView thumbnail, with a close control at the upper-right corner.
- Tab action menu includes group entries, destructive red close actions, and New Tab Group.
- Bookmark/favourite rows retain their close/remove control.
- Navigation action now reports unavailable back/forward history and refreshes enabled state after a request.

This is a source archive, not a tested APK. A successful GitHub Actions run and on-device verification are still required.
