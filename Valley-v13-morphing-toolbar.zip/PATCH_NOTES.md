# Valley v13 — morphing toolbar states

- Based on the v12 project.
- The expanded and compact address pill now transition width, height, padding, gap, flex-basis, and related properties with a shared spring curve instead of switching the pill transform off with `!important`.
- Side controls collapse with width/opacity transitions rather than disappearing instantly, while the address placeholder remains fully visible.
- Existing spacing between menu rows and centered tabs-count layout are preserved.
- Source-only patch; Android build and device animation have not been verified.
