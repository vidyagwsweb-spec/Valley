# Valley v10.1 — menu width correction without tighter row spacing

Based on v10, preserving the existing rounded corners, anchoring, tabs controls, menu animation and seven-row target.

- Kept the narrower menu width to remove unused right-side space.
- Restored the previous vertical row spacing: 6px vertical padding and 36px minimum row height. Row icon/text gap restored to 10px.
- Kept rounded row corners, horizontal/vertical fade treatment, and existing animation changes.

Validation: source archive created and JavaScript syntax checked. No Android APK build or on-device visual test was performed.
