Valley v16 — toolbar actions, reader fallback, compact URL alignment

- Removed Smart search from the special page-tools menu (the search-panel preference remains).
- Reader mode now treats closing Reader as a successful action and has a visible-paragraph fallback for pages without semantic article wrappers.
- Reload now calls the active WebView reload directly and updates loading state.
- Translate now calls the page translator and falls back to visible translation controls, with a clear unavailable message.
- Centered the minimized address label and changed fade eligibility to measure only the hostname, not URL paths or query strings.
- Repaired the Kotlin regex string escape in history synchronization.

Validation: toolbar.html and reader.js JavaScript syntax checks are run separately; APK compilation/device testing is not claimed.
