Reader mode repair

- Replaced the reader extraction script with a standalone implementation that searches semantic article containers, then visible paragraph/content blocks, then a body-text fallback.
- Reader overlay is created directly in the active page WebView and can be toggled off by pressing the reader control again.
- Updated the native bridge path to run the script on the target WebView thread and report a clear message if extraction fails.
- JavaScript syntax checked with Node.js. Android APK build/device behaviour has not been verified in this environment.
