Valley preview patch notes

- Keeps the compact menu and toolbar changes from the previous preview.
- Prevents saving the same normalized page URL more than once across Favourites and Bookmarks.
- URL comparison ignores fragments, leading www., default HTTP(S) ports, and trailing slashes; query strings remain significant.
- Cleans duplicate normalized URLs when syncing the homepage favourites list.

Build status: source-only patch. Android compilation and on-device testing have not been performed here.
