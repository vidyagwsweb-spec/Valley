
  var bar = document.getElementById('bar');
  var addr = document.getElementById('addr');
  var frost = document.getElementById('frost');
  var fwd = false;

  function native(name, arg) {
    try { if (window.ValleyNative && window.ValleyNative[name]) window.ValleyNative[name](arg); } catch (e) {}
  }

  /* called from Kotlin */
  window.ulaaSetAddr = function (text) {
    if (addr.textContent !== text) {
      addr.textContent = text;
      addr.scrollLeft = 0;
      addr.style.opacity = '.4';
      requestAnimationFrame(function () { addr.style.opacity = '1'; });
    }
  };
  window.ulaaSetFrost = function (dataUrl) {
    frost.style.backgroundImage = 'url("' + dataUrl + '")';
  };
  var pillEl = document.getElementById('pill');
  var readerEl = document.getElementById('reader');
  var reloadEl = document.getElementById('reload');

  /* Estimate visible address width for the compact expanded pill. */
  function chPx() {
    var s = document.createElement('span');
    s.style.cssText = 'position:absolute;left:-9999px;top:0;width:1ch;' +
      'font:500 13px/1.2 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif';
    document.body.appendChild(s);
    var w = s.getBoundingClientRect().width || 7;
    s.remove();
    return w || 7;
  }
  function bigCh() {
    var room = (window.innerWidth - 20) / 1.08 - 132;
    return Math.max(14, Math.min(40, Math.floor(room / chPx())));
  }

  /* Expanded mode stays compact so the pill does not collide visually with the outer controls. */
  function setBig(big) {
    var s = big ? 1.08 : 1;
    bar.classList.toggle('small', !big);
    bar.style.padding = big ? '0 10px' : '0 6px';
    pillEl.style.transform = 'scale(' + s + ')';
    pillEl.style.padding = big ? '0 10px' : '0 6px';
    addr.style.fontSize = (big ? 13 / s : 11) + 'px';
    addr.style.maxWidth = Math.round(big ? bigCh() * 5.3 : 14 * 5.83) + 'px';
    readerEl.style.maxWidth = big ? '15px' : '0px';
    readerEl.style.opacity = big ? '1' : '0';
    reloadEl.style.maxWidth = big ? '21px' : '0px';
    reloadEl.style.opacity = big ? '1' : '0';
  }
  window.ulaaBig = function (big) { setBig(!!big); };
  window.ulaaMin = function (min) { setBig(!min); };
  setBig(true);
  var addressBeforeCount = null;
  window.ulaaCount = function (text) {
    if (text) {
      if (!bar.classList.contains('count')) addressBeforeCount = addr.textContent;
      bar.classList.add('count');
      addr.textContent = text;
      addr.scrollLeft = 0;
    } else {
      bar.classList.remove('count');
      if (addressBeforeCount !== null) addr.textContent = addressBeforeCount;
      addressBeforeCount = null;
      addr.scrollLeft = 0;
    }
  };
  window.ulaaSetAddr = function (text) {
    addressBeforeCount = text || 'Search or enter website';
    if (!bar.classList.contains('count')) addr.textContent = addressBeforeCount;
  };
  window.ulaaForward = function (on) {
    fwd = !!on;
    document.querySelector('#nav svg path').setAttribute('d', fwd ? 'M9 5l7 7-7 7' : 'M15 5l-7 7 7 7');
  };
  window.ulaaDim = function (on) {
    document.getElementById('nav').style.opacity = on ? '.4' : '1';
  };

  var orb = document.getElementById('orb');
  var tools = document.getElementById('tools');
  var pressTimer = null;
  var longPressed = false;

  function fold(on) {
    if (on) {
      var r = pillEl.getBoundingClientRect();
      orb.style.left = (r.left + r.width / 2) + 'px';
      orb.style.marginLeft = '-27px';
      orb.style.bottom = (window.innerHeight - (r.top + r.height / 2)) + 'px';
      orb.classList.add('on');
      bar.classList.add('fold');
      requestAnimationFrame(function () {
        orb.style.left = '50%';
        orb.style.bottom = '33vh';
        orb.style.marginLeft = '-27px';
      });
    } else {
      bar.classList.remove('fold');
      orb.classList.remove('on');
      tools.classList.remove('on');
      orb.style.left = '50%';
      orb.style.bottom = '33vh';
      orb.style.marginLeft = '-27px';
    }
    native('folded', !!on);   /* the surface grows so the tools are never clipped */
  }

  function startPress(e) {
    longPressed = false;
    pressTimer = setTimeout(function () {
      longPressed = true;
      fold(true);
      if (navigator.vibrate) navigator.vibrate(12);
    }, 480);
  }
  function cancelPress() { clearTimeout(pressTimer); }

  var navTimer = null;
  var navEl = document.getElementById('nav');
  navEl.addEventListener('pointerdown', function () {
    navTimer = setTimeout(function () { openPanel('nav'); }, 480);
  });
  ['pointerup', 'pointercancel', 'pointerleave'].forEach(function (ev) {
    navEl.addEventListener(ev, function () { clearTimeout(navTimer); });
  });

  ['pill', 'menu'].forEach(function (id) {
    var el = document.getElementById(id);
    el.addEventListener('pointerdown', startPress);
    el.addEventListener('pointerup', cancelPress);
    el.addEventListener('pointercancel', cancelPress);
    el.addEventListener('pointerleave', cancelPress);
  });

  orb.addEventListener('click', function () {
    tools.classList.toggle('on');
    if (tools.classList.contains('on')) {
      var r = orb.getBoundingClientRect();
      var space = window.innerHeight - r.top;
      tools.style.bottom = (space + 8) + 'px';
      tools.style.left = (r.left + r.width / 2) + 'px';
      tools.style.transformOrigin = '50% 100%';
    }
  });

  /* drag the orb anywhere; tap still opens the tools */
  (function () {
    var dragging = false, sx = 0, sy = 0, ox = 0, oy = 0, moved = false;
    orb.addEventListener('pointerdown', function (e) {
      dragging = true; moved = false;
      sx = e.clientX; sy = e.clientY;
      var r = orb.getBoundingClientRect();
      ox = r.left; oy = window.innerHeight - r.bottom;
      orb.setPointerCapture(e.pointerId);
    });
    orb.addEventListener('pointermove', function (e) {
      if (!dragging) return;
      var dx = e.clientX - sx, dy = e.clientY - sy;
      if (Math.abs(dx) + Math.abs(dy) > 6) moved = true;
      var nx = Math.min(Math.max(ox + dx, 6), window.innerWidth - orb.offsetWidth - 6);
      var nb = Math.min(Math.max(oy - dy, 6), window.innerHeight - orb.offsetHeight - 6);
      orb.style.left = nx + 'px'; orb.style.marginLeft = '0px';
      orb.style.bottom = nb + 'px';
      if (moved) tools.classList.remove('on');
    });
    orb.addEventListener('pointerup', function (e) {
      dragging = false;
      if (moved) { e.stopPropagation(); }
    });
  })();

  document.querySelectorAll('.tool').forEach(function (t) {
    t.addEventListener('click', function () {
      native('tool', t.getAttribute('data-tool'));
      tools.classList.remove('on');
      fold(false);
    });
  });

  var sheet = document.getElementById('sheet');
  var navwide = document.getElementById('navwide');

  function openPanel(name) {
    sheet.setAttribute('data-open', name);
    if (name === 'search') native('smartstate');
    sheet.classList.add('on');
    native('surface', true);
    if (name === 'search') setTimeout(function () { document.getElementById('q').focus(); }, 120);
  }
  function closePanel() {
    sheet.classList.remove('on');
    native('surface', false);
  }

  document.querySelectorAll('[data-act]').forEach(function (el) {
    el.addEventListener('click', function () {
      var act = el.getAttribute('data-act');
      if (act === 'go') {
        var q = document.getElementById('q');
        if (q && q.value.trim()) native('search', q.value.trim());
        q.value = '';
        closePanel();
        return;
      }
      if (act === 'navtoggle') {
        var now = navwide.textContent === 'Back' ? 'Forward' : 'Back';
        navwide.textContent = now;
        native('navmode', now);
        return;
      }
      native('action', act);
      closePanel();
    });
  });

  var smartToggle = document.getElementById('smartToggle');
  window.ulaaSetSmart = function (enabled) { if (smartToggle) smartToggle.checked = !!enabled; };
  smartToggle.addEventListener('change', function () { native('smartsetting', !!this.checked); });

  document.getElementById('q').addEventListener('keydown', function (e) {
    if (e.key === 'Enter') {
      e.preventDefault();
      if (this.value.trim()) native('search', this.value.trim());
      this.value = '';
      closePanel();
    }
  });

  /* tapping the page outside a panel closes it */
  document.addEventListener('pointerdown', function (e) {
    if (!sheet.classList.contains('on')) return;
    if (sheet.contains(e.target) || e.target.id === 'pill') return;
    closePanel();
  });

  window.ulaaOpenPanel = function (name) { openPanel(name); };
  window.ulaaClosePanel = function () { closePanel(); };
  window.ulaaNavLabel = function (text) { if (navwide) navwide.textContent = text; };

  document.getElementById('nav').addEventListener('click', function () {
    if (bar.classList.contains('count')) native('addtabmenu'); else native('nav');
  });
  document.getElementById('menu').addEventListener('click', function () {
    if (bar.classList.contains('count')) native('tabactions'); else openPanel('settings');
  });
  document.getElementById('reader').addEventListener('click', function (e) { e.stopPropagation(); native('reader'); });
  document.getElementById('reload').addEventListener('click', function (e) { e.stopPropagation(); native('reload'); });
  document.getElementById('pill').addEventListener('click', function (e) {
    if (longPressed) { longPressed = false; return; }
    if (e.target.closest && e.target.closest('#reader, #reload')) return;
    if (bar.classList.contains('count')) return;
    openPanel('search');
  });

  /* Kotlin can fold/unfold the orb too */
  window.ulaaFold = function (on) { fold(!!on); };
