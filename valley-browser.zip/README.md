# Valley

An Android browser shell around WebView: your homepage as the start page, and a bottom toolbar
in the shape of the iOS 26 pill row.

```
( ← )   [ ▤   url.com   ⟳ ]   ( ⋯ )
```

- **( ← )** goes to the previous page
- **▤** opens the tabs sheet
- the address in the middle — tap it to type
- **⟳** reloads
- **( ⋯ )** opens the Safari-style menu: Share, Add to Favourites, Add Bookmark to…, New Tab,
  New Private Tab, and a Bookmarks / All Tabs pair
- **long-press ( ⋯ )** opens the page tools: Translate, Eraser, Summarise, Smart search, Copy
  link, Home
- **long-press ( ← )** opens the Back / Forward popover with a segmented control showing which
  direction is live

The page tools that used to float over the page as the Valley pill now live behind the long
press. The pill is still injected on every site — it just hides itself, and the menu calls into it.

## Build it

1. Put `valley-browser.zip` in the root of your repository.
2. Add `.github/workflows/build.yml` (the small workflow).
3. Actions runs, unzips, builds, and hands you `valley-debug-apk`.

## What it does

- **Start page** — your homepage, served from inside the app over a real `https://` origin, so
  `localStorage`, geolocation and `fetch` behave as they do on GitHub Pages. History, Security and
  About are views inside that same single file, not separate pages.
- **Tabs** — one WebView per tab. Switching detaches the old one and attaches the new one, so
  scroll position, form state and video all survive. Closing a tab destroys its WebView.
- **Page tools** — translate, eraser and the AI summary are still the pill's code, driven from
  the native menu via `window.ulaaTranslate()`, `ulaaEraser()`, `ulaaSummarise()`.
- **No ads, no telemetry, no accounts.**

## Security (always on, not configurable)

There is no switch to turn these off. They are part of how the browser works:

- **Ads and trackers blocked** — requests to ~130 ad/tracker hosts are answered with an empty
  body. Subresources only; the page itself is never blocked, so nothing white-screens.
- **Third-party cookies blocked** — always, in every tab.
- **HTTPS only** — a plain `http://` navigation is upgraded to `https://` and reloaded.
- **No local file access, no content access, no script popups, no saved form data, no mixed
  content**, and **Google Safe Browsing** for phishing and malware on API 26+.
- **Private tabs** additionally write no site storage and keep nothing in the cache.

Because these are baked in, they are also the reason a few sites will misbehave: a login that
needs a third-party cookie, or a site that only serves `http`, may refuse to work. That is the
trade-off for having protection on by default.

## Known limits

- **Private tabs** — a private tab writes no site storage (`domStorageEnabled` off), blocks
  third-party cookies (that setting *is* per-WebView) and never touches the disk cache. When the
  last private tab closes, all cookies are wiped. Android has one cookie jar for the whole app,
  so that wipe also signs you out of normal tabs — the dialog says so before you open one.
  The homepage in a private tab shows a fresh install, because it has no storage to read.
- No ad-blocking, no reader mode, no downloads manager yet.
- It is WebView with a shell around it, not a new engine.
