# Valley

An Android browser shell around WebView, with **your** homepage as its start page and the
Valley pill injected into every site — the Site Sparks idea, without needing Sparks.

The homepage, history and about pages are bundled inside the APK, so the app works with no
network at all until you navigate somewhere.

## Build it

The APK is built by GitHub Actions — no Android Studio, no PC required.

1. Create a new **public** repository on GitHub (any name, e.g. `valley-browser`).
2. Upload every file and folder from this zip to the repository root, keeping the structure:
   ```
   settings.gradle
   build.gradle
   gradle.properties
   app/
   .github/workflows/build.yml
   ```
   The `.github` folder must keep that exact name — it is what runs the build.
3. Commit. Then open the **Actions** tab.
4. Wait 3–6 minutes. The first run downloads Gradle and the Android SDK, so it is the slowest.
5. Open the finished run, scroll to **Artifacts**, download **valley-debug-apk**.
6. Unzip it — you get `app-debug.apk`.
7. Open the APK on your phone and allow "install from unknown sources" when asked.

Debug APKs are signed with a throwaway key, which is why Android warns you. That is normal
for a personal build; it just means the Play Store is not involved.

## What it does

- **Start page** — your homepage, served from inside the app over a real `https://` origin
  (`appassets.androidplatform.net`), so `localStorage`, geolocation and `fetch` all behave
  exactly as they do on GitHub Pages. Your dial, favourites, notes and history persist.
- **The pill** — `spark.js` is injected after every page loads, except on the app's own
  pages. Long-press for the menu, translate, copy, eraser, the summary orb, all of it.
- **URL bar** — an address goes there, anything else searches Brave. Same rule as the page.
- **Back / forward / home** — hardware back button walks the history, then exits.
- **No ads, no telemetry, no accounts.** The app makes exactly the requests the page makes.

## What it deliberately does not do

- No tabs yet — one WebView, one history. Tabs are the next piece of work.
- No ad-blocking, no reader mode.
- It is not a new browser engine; it is Android's WebView with a shell around it, which is
  what most browsers on the Play Store are.

## Changing things

- The start page lives in `app/src/main/assets/`. Replace `index.html` to change it.
- The pill is `app/src/main/assets/spark.js`. Replace it with a newer build.
- App name, colours and icon: `res/values/strings.xml`, `res/values/styles.xml`, `res/drawable/`.
- After any change, commit — Actions rebuilds automatically.
