(function () {
  if (window.__ulaaReaderReady) return;
  window.__ulaaReaderReady = 1;
  var host = null;

  function pick() {
    var cands = [].slice.call(document.querySelectorAll(
      'article, main, [role=main], .post-content, .article-body, .entry-content, .article, #content, .content'
    ));
    var best = null, bestScore = 0;
    cands.forEach(function (c) {
      var s = (c.innerText || '').length;
      if (s > bestScore) { bestScore = s; best = c; }
    });
    if (!best || bestScore < 500) {
      var divs = document.querySelectorAll('div, section');
      for (var i = 0; i < divs.length; i++) {
        var ps = divs[i].querySelectorAll('p');
        if (ps.length < 4) continue;
        var s = 0;
        for (var j = 0; j < ps.length; j++) s += (ps[j].innerText || '').length;
        if (s > bestScore) { bestScore = s; best = divs[i]; }
      }
    }
    return bestScore >= 300 ? best : null;
  }

  function esc(t) { return String(t).replace(/&/g, '&amp;').replace(/</g, '&lt;'); }

  window.ulaaReaderToggle = function () {
    if (host) { host.parentNode && host.parentNode.removeChild(host); host = null; return false; }
    var src = pick();
    if (!src) return false;

    var title = (document.querySelector('h1') || {}).innerText || document.title || '';
    var nodes = src.querySelectorAll('p, h1, h2, h3, li, blockquote, figcaption');
    var html = '';
    for (var i = 0; i < nodes.length; i++) {
      var el = nodes[i];
      var t = (el.innerText || '').trim();
      if (!t) continue;
      if (el.tagName === 'P' && t.length < 30) continue;
      var tag = 'p';
      if (el.tagName === 'H1') tag = 'h2';
      else if (el.tagName === 'H2') tag = 'h2';
      else if (el.tagName === 'H3') tag = 'h3';
      else if (el.tagName === 'LI') tag = 'li';
      else if (el.tagName === 'BLOCKQUOTE') tag = 'blockquote';
      html += '<' + tag + '>' + esc(t) + '</' + tag + '>';
    }
    if (html.length < 200) return false;

    host = document.createElement('div');
    host.id = 'ulaa-reader';
    host.style.cssText = 'position:fixed;inset:0;z-index:2147483647;overflow:auto;' +
      'background:#f6f1e9;color:#191410;padding:30px 22px 90px;' +
      'font:17px/1.72 Georgia,"Iowan Old Style",serif;-webkit-overflow-scrolling:touch';
    host.innerHTML =
      '<div style="max-width:640px;margin:0 auto">' +
        '<div style="font:600 10px/1 -apple-system,sans-serif;letter-spacing:.2em;' +
          'text-transform:uppercase;color:#a2978b;margin-bottom:16px">Reader</div>' +
        '<h1 style="font:italic 600 31px/1.15 Georgia,serif;letter-spacing:-.01em;margin:0 0 24px">' +
          esc(title) + '</h1>' + html +
        '<div style="margin-top:36px;padding-top:14px;border-top:1px solid #e4dbcd;' +
          'font:500 11px -apple-system,sans-serif;letter-spacing:.12em;text-transform:uppercase;' +
          'color:#a2978b">Reader \\u00b7 tap the reader button to close</div>' +
      '</div>';
    document.body.appendChild(host);
    host.scrollTop = 0;
    return true;
  };
})();
