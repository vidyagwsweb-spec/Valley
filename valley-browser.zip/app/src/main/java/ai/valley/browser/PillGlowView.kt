package ai.valley.browser

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator

/**
 * The loading indicator: a warm light that sweeps across the address pill while a page loads,
 * instead of a progress line. It clips itself to the pill's rounded shape.
 */
class PillGlowView(context: Context, attrs: AttributeSet? = null) : View(context, attrs) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bloom = Paint(Paint.ANTI_ALIAS_FLAG)
    private var pos = 0f
    private val rect = RectF()

    private val animator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1250
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            pos = it.animatedValue as Float
            invalidate()
        }
    }

    init {
        alpha = 0f
        clipToOutline = true
        outlineProvider = object : android.view.ViewOutlineProvider() {
            override fun getOutline(view: View, outline: android.graphics.Outline) {
                val r = view.height / 2f
                outline.setRoundRect(0, 0, view.width, view.height, r)
            }
        }
        bloom.setColor(0x66FF7A33)
        bloom.maskFilter = android.graphics.BlurMaskFilter(28f, android.graphics.BlurMaskFilter.Blur.NORMAL)
    }

    fun start() {
        if (animator.isStarted) return
        animator.start()
        animate().alpha(1f).setDuration(180).start()
    }

    fun stop() {
        if (!animator.isStarted) { animate().alpha(0f).setDuration(200).start(); return }
        animate().alpha(0f).setDuration(320).withEndAction {
            animator.cancel()
            invalidate()
        }.start()
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val sweep = w * 0.55f
        val cx = pos * (w + sweep * 2f) - sweep

        paint.shader = LinearGradient(
            cx - sweep, 0f, cx + sweep, 0f,
            intArrayOf(0x00FF7A33, 0x40FF7A33, 0xC4FFB347, 0x40FF7A33, 0x00FF7A33),
            floatArrayOf(0f, 0.28f, 0.5f, 0.72f, 1f),
            Shader.TileMode.CLAMP
        )
        rect.set(0f, 0f, w, h)
        canvas.drawRect(rect, paint)

        // a soft bloom at the centre of the sweep, so it reads as light rather than a stripe
        bloom.alpha = 90
        canvas.drawCircle(cx, h / 2f, h * 0.75f, bloom)
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }
}
