package ai.valley.browser

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.GeolocationPermissions
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewClientCompat
import java.io.ByteArrayInputStream
import java.net.URLEncoder

class MainActivity : Activity() {

    private inner class Tab(val web: WebView) {
        var title: String = "New Tab"
        var isPrivate: Boolean = false
    }

    private lateinit var container: FrameLayout
    private lateinit var urlView: TextView
    private lateinit var progress: ProgressBar
    private lateinit var assetLoader: WebViewAssetLoader
    private var sparkJs: String? = null

    private val tabs = ArrayList<Tab>()
    private var current = 0
    private var privateCount = 0

    // protection is always on - there is nothing to switch off

    /** hosts that serve ads and trackers; a request to one of these is answered with nothing */
    private val blocked: HashSet<String> by lazy {
        RAW_BLOCKLIST.trim().lines().map { it.trim() }.filter { it.isNotEmpty() }.toHashSet()
    }
    private val active: Tab get() = tabs[current]
    private val web: WebView get() = active.web

    companion object {
        private const val HOST = "appassets.androidplatform.net"
        private const val START_URL = "https://$HOST/assets/index.html"

        private val RAW_BLOCKLIST = """
            doubleclick.net
            googlesyndication.com
            googleadservices.com
            google-analytics.com
            googletagmanager.com
            googletagservices.com
            adservice.google.com
            pagead2.googlesyndication.com
            facebook.net
            connect.facebook.net
            scorecardresearch.com
            quantserve.com
            quantcount.com
            moatads.com
            adsafeprotected.com
            adnxs.com
            adsrvr.org
            rubiconproject.com
            pubmatic.com
            casalemedia.com
            openx.net
            appnexus.com
            criteo.com
            criteo.net
            taboola.com
            outbrain.com
            revcontent.com
            mgid.com
            zergnet.com
            popads.net
            propellerads.com
            adcash.com
            exoclick.com
            juicyads.com
            trafficjunky.net
            media.net
            smartadserver.com
            teads.tv
            spotxchange.com
            tremorhub.com
            amazon-adsystem.com
            ads.yahoo.com
            adtech.de
            adform.net
            serving-sys.com
            flashtalking.com
            mathtag.com
            turn.com
            tapad.com
            bidswitch.net
            sharethrough.com
            triplelift.com
            indexexchange.com
            sovrn.com
            gumgum.com
            districtm.io
            yieldmo.com
            sonobi.com
            lijit.com
            krxd.net
            bluekai.com
            demdex.net
            omtrdc.net
            2o7.net
            everesttech.net
            adsymptotic.com
            agkn.com
            rlcdn.com
            tapfiliate.com
            branch.io
            appsflyer.com
            adjust.com
            kochava.com
            amplitude.com
            mixpanel.com
            segment.com
            segment.io
            heap.io
            hotjar.com
            hotjar.io
            fullstory.com
            clarity.ms
            inspectlet.com
            mouseflow.com
            smartlook.com
            luckyorange.com
            crazyegg.com
            optimizely.com
            vwo.com
            newrelic.com
            nr-data.net
            bugsnag.com
            rollbar.com
            sentry.io
            loggly.com
            chartbeat.com
            chartbeat.net
            parsely.com
            nr-data.net
            clicktale.net
            userreport.com
            mc.yandex.ru
            top-fwz1.mail.ru
            hb.wrating.com
            ctnsnet.com
            creativecdn.com
            adroll.com
            perfectaudience.com
            rebound.net
            retargeter.com
            steelhousemedia.com
            simpli.fi
            audienceproject.com
            narrative.io
            permutive.com
            id5-sync.com
            liadm.com
            pippio.com
            ads.linkedin.com
            analytics.tiktok.com
            business-api.tiktok.com
            ads.tiktok.com
            analytics.twitter.com
            static.ads-twitter.com
            ads.pinterest.com
            ads.reddit.com
            ads.snapchat.com
            sc-static.net
            tr.snapchat.com
        """
    }

    private fun isBlocked(host: String?): Boolean {
        if (host == null) return false
        val h = host.lowercase()
        if (blocked.contains(h)) return true
        // walk the parent domains instead of scanning the whole list per request
        var i = h.indexOf('.')
        while (i != -1) {
            if (blocked.contains(h.substring(i + 1))) return true
            i = h.indexOf('.', i + 1)
        }
        return false
    }

    private fun emptyResponse(): WebResourceResponse =
        WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        container = findViewById(R.id.web_container)
        urlView = findViewById(R.id.url)
        progress = findViewById(R.id.progress)

        assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        sparkJs = readAsset("spark.js")


        findViewById<ImageButton>(R.id.back).setOnClickListener {
            if (web.canGoBack()) web.goBack() else toast("No page to go back to")
        }
        findViewById<ImageButton>(R.id.reload).setOnClickListener { web.reload() }
        urlView.setOnClickListener { editUrl() }
        findViewById<ImageButton>(R.id.tabs).setOnClickListener { showTabs() }

        val settingsBtn = findViewById<ImageButton>(R.id.settings)
        settingsBtn.setOnClickListener { showPageMenu() }
        settingsBtn.setOnLongClickListener { showPageTools(); true }

        findViewById<ImageButton>(R.id.back).setOnLongClickListener { showBackForward(); true }

        newTab(START_URL)
    }

    // ---------------------------------------------------------------- tabs

    @SuppressLint("SetJavaScriptEnabled")
    private fun buildWeb(private: Boolean = false): WebView {
        val w = WebView(this)
        w.settings.apply {
            javaScriptEnabled = true
            // a private tab writes no site storage at all
            domStorageEnabled = !private
            databaseEnabled = !private
            // hardening: no local file access, no popups, no saved form data
            allowFileAccess = false
            allowContentAccess = false
            allowFileAccessFromFileURLs = false
            allowUniversalAccessFromFileURLs = false
            javaScriptCanOpenWindowsAutomatically = false
            saveFormData = false
            if (android.os.Build.VERSION.SDK_INT >= 26) safeBrowsingEnabled = true
            useWideViewPort = true
            loadWithOverviewMode = true
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            // nothing is read from or written to the disk cache
            cacheMode = if (private) WebSettings.LOAD_NO_CACHE else WebSettings.LOAD_DEFAULT
            userAgentString = userAgentString.replace("; wv", "")
        }
        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            // third-party cookies are blocked per-WebView, so this really is per-tab
            // third-party cookies are blocked everywhere except where a site needs them
            setAcceptThirdPartyCookies(w, false)
        }

        w.webViewClient = object : WebViewClientCompat() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? {
                assetLoader.shouldInterceptRequest(request.url)?.let { return it }
                // never block the page itself, only what it pulls in
                if (!request.isForMainFrame && isBlocked(request.url.host)) return emptyResponse()
                return null
            }

            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean {
                val u = request.url
                // HTTPS only: upgrade plain http, refuse it if the host has no https
                if (u.scheme == "http") {
                    val secure = u.toString().replaceFirst("http://", "https://")
                    view.loadUrl(secure)
                    return true
                }
                return false
            }

            override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
                super.onPageStarted(view, url, favicon)
                if (view == web) progress.visibility = View.VISIBLE
            }

            override fun onPageFinished(view: WebView, url: String?) {
                super.onPageFinished(view, url)
                val tab = tabs.firstOrNull { it.web === view }
                if (url != null && tab != null && (tab.title == "New Tab" || tab.title.isBlank())) {
                    tab.title = prettyUrl(url)
                }
                if (view == web) {
                    progress.visibility = View.GONE
                    if (url != null) showAddress(url)
                    refreshBack()
                }
                injectSpark(view, url)
            }
        }

        w.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                if (view == web) {
                    progress.progress = newProgress
                    progress.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
                }
            }

            override fun onReceivedTitle(view: WebView?, title: String?) {
                val tab = tabs.firstOrNull { it.web === view }
                if (tab != null && !title.isNullOrBlank()) tab.title = title
            }

            override fun onGeolocationPermissionsShowPrompt(
                origin: String?,
                callback: GeolocationPermissions.Callback?
            ) {
                callback?.invoke(origin, origin != null && origin.contains(HOST), false)
            }
        }
        return w
    }

    /** a new tab gets its own WebView, so scroll position and form state survive switching */
    private fun newTab(url: String, private: Boolean = false) {
        val w = buildWeb(private)
        val tab = Tab(w)
        tab.isPrivate = private
        if (private) tab.title = "Private"
        privateCount += if (private) 1 else 0
        tabs.add(tab)
        current = tabs.size - 1
        attach()
        w.loadUrl(url)
        showAddress(url)
        refreshBack()
    }

    private fun attach() {
        container.removeAllViews()
        val w = active.web
        container.addView(w, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        showAddress(w.url ?: START_URL)
        refreshBack()
    }

    private fun showAddress(url: String) {
        val label = prettyUrl(url)
        if (active.isPrivate) {
            urlView.text = "\u25D0  " + label
            urlView.setTextColor(0xFFCBA8FF.toInt())
        } else {
            urlView.text = label
            urlView.setTextColor(0xFFF6F0E8.toInt())
        }
    }

    private fun switchTo(index: Int) {
        if (index !in tabs.indices) return
        current = index
        attach()
    }

    private fun closeTab(index: Int) {
        if (index !in tabs.indices) return
        val gone = tabs.removeAt(index)
        if (gone.isPrivate) privateCount = (privateCount - 1).coerceAtLeast(0)
        val needWipe = gone.isPrivate && privateCount == 0
        try { gone.web.destroy() } catch (e: Exception) {}
        if (tabs.isEmpty()) {
            newTab(START_URL)
        } else {
            current = index.coerceAtMost(tabs.size - 1)
            attach()
        }
        if (needWipe) wipePrivateSession()
    }

    /**
     * Android gives the whole app one cookie jar, so a private tab cannot have a separate one.
     * What we can do: while private tabs are open nothing is written to site storage or the
     * disk cache, and when the last one closes the cookies and cache are destroyed.
     */
    private fun wipePrivateSession() {
        try {
            val cm = CookieManager.getInstance()
            cm.removeAllCookies(null)
            cm.flush()
        } catch (e: Exception) {}
        try { web.clearCache(true) } catch (e: Exception) {}
        try { web.clearFormData() } catch (e: Exception) {}
        try { web.clearHistory() } catch (e: Exception) {}
    }

    private fun refreshBack() {
        findViewById<ImageButton>(R.id.back).alpha = if (web.canGoBack()) 1f else 0.35f
    }

    private fun prettyUrl(url: String): String = try {
        if (url.contains(HOST)) "Valley" else java.net.URL(url).host.replace("^www\\.".toRegex(), "")
    } catch (e: Exception) {
        url
    }

    // ---------------------------------------------------------------- url bar

    private fun editUrl() {
        val input = EditText(this).apply {
            setText(if (web.url == null || web.url!!.contains(HOST)) "" else web.url)
            setSingleLine(true)
            setTextColor(Color.WHITE)
            hint = getString(R.string.url_hint)
            setPadding(36, 36, 36, 36)
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle("Address")
            .setView(input)
            .setPositiveButton("Go") { _, _ ->
                val typed = input.text.toString().trim()
                if (typed.isNotEmpty()) web.loadUrl(toUrl(typed))
            }
            .setNegativeButton("Cancel", null)
            .create()

        dialog.setOnShowListener {
            input.requestFocus()
            val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(input, InputMethodManager.SHOW_IMPLICIT)
        }
        dialog.show()
    }

    private fun toUrl(input: String): String {
        val t = input.trim()
        if (t.startsWith("http://") || t.startsWith("https://") || t.startsWith("file://")) return t
        val looksLikeHost = !t.contains(" ") &&
                Regex("^[^\\s/?#]+\\.[a-z]{2,}([/?#].*)?$", RegexOption.IGNORE_CASE).containsMatchIn(t)
        return if (looksLikeHost) "https://$t"
        else "https://search.brave.com/search?q=" + URLEncoder.encode(t, "UTF-8")
    }

    // ---------------------------------------------------------------- menus

    private fun showPageMenu() {
        val card = menuCard()
        card.addView(menuRow(R.drawable.ic_share, "Share") { shareCurrent() })
        card.addView(menuRow(R.drawable.ic_star, "Add to Favourites") { saveLink("favs") })
        card.addView(menuRow(R.drawable.ic_bookmark, "Add Bookmark to\u2026") { saveLink("bookmarks") })
        card.addView(menuDivider())
        card.addView(menuRow(R.drawable.ic_plus, "New Tab") { newTab(START_URL) })
        card.addView(menuRow(R.drawable.ic_mask, "New Private Tab") { privateTab() })
        card.addView(twoUpRow())
        showCard(card)
    }

    private fun showPageTools() {
        val card = menuCard()
        card.addView(menuRow(R.drawable.ic_translate, "Translate page") { js("window.ulaaTranslate && window.ulaaTranslate()") })
        card.addView(menuRow(R.drawable.ic_eraser, "Eraser") { js("window.ulaaEraser && window.ulaaEraser()") })
        card.addView(menuRow(R.drawable.ic_summary, "Summarise page") { js("window.ulaaSummarise && window.ulaaSummarise()") })
        card.addView(menuDivider())
        card.addView(menuRow(R.drawable.ic_smart, "Smart search") { showSmartSearch() })
        card.addView(menuRow(R.drawable.ic_copy, "Copy link") {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("link", web.url ?: ""))
            toast("Link copied")
        })
        card.addView(menuRow(R.drawable.ic_home, "Home") { web.loadUrl(START_URL) })
        showCard(card)
    }

    private fun showBackForward() {
        val card = menuCard()
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(4), dp(10), dp(4), dp(10))
        }
        row.addView(dirTile(R.drawable.ic_chevron_left, "Back", web.canGoBack()) {
            if (web.canGoBack()) { web.goBack(); dismissLater() }
        }, weight())
        row.addView(dirTile(R.drawable.ic_chevron_right, "Forward", web.canGoForward()) {
            if (web.canGoForward()) { web.goForward(); dismissLater() }
        }, weight())
        card.addView(row)

        card.addView(View(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(1)).also { it.setMargins(dp(12), dp(2), dp(12), dp(10)) }
            setBackgroundColor(0x22FFFFFF)
        })

        val seg = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = GradientDrawable().apply {
                cornerRadius = dp(999).toFloat(); setColor(0x1FFFFFFF)
            }
            setPadding(dp(3), dp(3), dp(3), dp(3))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                .also { it.setMargins(dp(10), 0, dp(10), dp(10)) }
        }
        seg.addView(segment("Back", web.canGoBack()) { if (web.canGoBack()) { web.goBack(); dismissLater() } }, weight())
        seg.addView(segment("Forward", web.canGoForward()) { if (web.canGoForward()) { web.goForward(); dismissLater() } }, weight())
        card.addView(seg)
        showCard(card)
    }

    private fun privateTab() {
        AlertDialog.Builder(this)
            .setTitle("New Private Tab")
            .setMessage("Private tabs write no site storage, block third-party cookies and keep nothing " +
                    "in the cache.\n\nWhen you close the last one, all cookies are wiped — which also " +
                    "signs you out of sites in your normal tabs. Android shares one cookie jar, so that " +
                    "is the price of it.")
            .setPositiveButton("Open") { _, _ -> newTab(START_URL, true) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showTabs() {
        val names = tabs.mapIndexed { i, t ->
            val dot = if (i == current) "\u25CF  " else "\u25CB  "
            dot + (if (t.isPrivate) "\u25D0 Private \u00B7 " else "") + t.title
        }.toMutableList()
        names.add("\uFF0B  New tab")
        names.add("\uFF0B  New private tab")
        names.add("\u2715  Close this tab")
        if (privateCount > 0) names.add("\u2715  Close all private tabs")

        val newTabAt = tabs.size
        val newPrivateAt = tabs.size + 1
        val closeAt = tabs.size + 2
        val closeAllAt = tabs.size + 3

        AlertDialog.Builder(this)
            .setTitle("All Tabs")
            .setItems(names.toTypedArray()) { _, which ->
                when (which) {
                    newTabAt -> newTab(START_URL)
                    newPrivateAt -> newTab(START_URL, true)
                    closeAt -> closeTab(current)
                    closeAllAt -> for (i in tabs.indices.reversed()) if (tabs[i].isPrivate) closeTab(i)
                    else -> switchTo(which)
                }
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun showBookmarks() {
        val favs = (prefs().getString("list_favs", "") ?: "").split("\n").filter { it.isNotBlank() }
        val marks = (prefs().getString("list_bookmarks", "") ?: "").split("\n").filter { it.isNotBlank() }
        val urls = favs + marks
        if (urls.isEmpty()) { toast("Nothing saved yet"); return }
        val items = (favs.map { "\u2605  " + prettyUrl(it) } + marks.map { "\u25C6  " + prettyUrl(it) }).toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Saved")
            .setItems(items) { _, which -> newTab(urls[which]) }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun showSmartSearch() {
        AlertDialog.Builder(this)
            .setTitle("Smart search")
            .setMessage("When on, a query naming a site opens that site's own search. When off, everything goes to Brave as typed.")
            .setPositiveButton("On") { _, _ -> js("window.ulaaSmartSet && window.ulaaSmartSet(true)") }
            .setNegativeButton("Off") { _, _ -> js("window.ulaaSmartSet && window.ulaaSmartSet(false)") }
            .show()
    }

    // ---------------------------------------------------------------- menu pieces

    private fun twoUpRow(): LinearLayout {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(bigTile(R.drawable.ic_bookmarks, "Bookmarks") { showBookmarks() }, weight())
        row.addView(bigTile(R.drawable.ic_tabs, "All Tabs") { showTabs() }, weight())
        return row
    }

    private fun weight() = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)

    private fun bigTile(icon: Int, label: String, onClick: () -> Unit): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = android.view.Gravity.CENTER
            setPadding(0, dp(10), 0, dp(12))
            isClickable = true
            setOnClickListener { onClick() }
        }
        box.addView(ImageView(this).apply {
            setImageResource(icon)
            layoutParams = LinearLayout.LayoutParams(dp(22), dp(22))
        })
        box.addView(TextView(this).apply {
            text = label
            setTextColor(0xFFEDE7E0.toInt())
            textSize = 11.5f
            gravity = android.view.Gravity.CENTER
            setPadding(0, dp(6), 0, 0)
        })
        return box
    }

    private fun dirTile(icon: Int, label: String, enabled: Boolean, onClick: () -> Unit): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = android.view.Gravity.CENTER
            isClickable = true
            alpha = if (enabled) 1f else 0.35f
            setOnClickListener { onClick() }
        }
        box.addView(ImageView(this).apply {
            setImageResource(icon)
            layoutParams = LinearLayout.LayoutParams(dp(22), dp(22))
        })
        box.addView(TextView(this).apply {
            text = label
            setTextColor(0xFFEDE7E0.toInt())
            textSize = 12.5f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(6), 0, 0)
        })
        return box
    }

    private fun segment(label: String, active: Boolean, onClick: () -> Unit): TextView {
        val tv = TextView(this)
        tv.text = label
        tv.gravity = android.view.Gravity.CENTER
        tv.textSize = 13f
        tv.setPadding(0, dp(9), 0, dp(9))
        tv.setTextColor(if (active) 0xFFF6F0E8.toInt() else 0x99FFFFFF.toInt())
        if (active) {
            tv.background = GradientDrawable().apply {
                cornerRadius = dp(999).toFloat(); setColor(0x33FFFFFF)
            }
        }
        tv.isClickable = true
        tv.setOnClickListener { onClick() }
        return tv
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun menuCard(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(6), dp(6), dp(6), dp(6))
        background = getDrawable(R.drawable.menu_bg)
    }

    private fun menuDivider(): View = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(1)).also { it.setMargins(dp(10), dp(6), dp(10), dp(6)) }
        setBackgroundColor(0x22FFFFFF)
    }

    private fun menuRow(icon: Int, label: String, onClick: () -> Unit): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(13), dp(12), dp(13))
            isClickable = true
            setOnClickListener { onClick() }
        }
        row.addView(ImageView(this).apply {
            setImageResource(icon)
            layoutParams = LinearLayout.LayoutParams(dp(19), dp(19))
        })
        row.addView(TextView(this).apply {
            text = label
            setTextColor(0xFFF6F0E8.toInt())
            textSize = 15f
            setPadding(dp(14), 0, 0, 0)
        })
        return row
    }

    private var lastDialog: Dialog? = null

    private fun showCard(card: LinearLayout) {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE)
        val wrap = FrameLayout(this)
        wrap.setPadding(dp(10), 0, dp(10), dp(10))
        wrap.addView(card, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT))
        dialog.setContentView(wrap)
        val win = dialog.window
        if (win != null) {
            win.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            val lp = android.view.WindowManager.LayoutParams()
            lp.copyFrom(win.attributes)
            lp.width = android.view.WindowManager.LayoutParams.MATCH_PARENT
            lp.height = android.view.WindowManager.LayoutParams.WRAP_CONTENT
            lp.gravity = android.view.Gravity.BOTTOM
            win.attributes = lp
        }
        lastDialog = dialog
        dialog.show()
    }

    private fun dismissLater() {
        val d = lastDialog
        lastDialog = null
        try { d?.dismiss() } catch (e: Exception) {}
    }

    // ---------------------------------------------------------------- misc

    private fun shareCurrent() {
        val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(android.content.Intent.EXTRA_TEXT, web.url ?: "")
        }
        startActivity(android.content.Intent.createChooser(intent, "Share"))
    }

    private fun prefs(): SharedPreferences = getSharedPreferences("valley", MODE_PRIVATE)

    private fun saveLink(bucket: String) {
        val url = web.url ?: return
        val key = "list_$bucket"
        val all = (prefs().getString(key, "") ?: "").split("\n").filter { it.isNotBlank() }.toMutableList()
        if (all.contains(url)) { toast("Already saved"); return }
        all.add(0, url)
        prefs().edit().putString(key, all.joinToString("\n")).apply()
        toast(if (bucket == "favs") "Added to Favourites" else "Added to Bookmarks")
    }

    private fun js(code: String) {
        try { web.evaluateJavascript(code, null) } catch (e: Exception) {}
    }

    private fun injectSpark(view: WebView, url: String?) {
        val code = sparkJs ?: return
        if (url == null || url.contains(HOST)) return
        try {
            view.evaluateJavascript(code) {
                try { view.evaluateJavascript("window.ulaaHidePill && window.ulaaHidePill()", null) } catch (e: Exception) {}
            }
        } catch (e: Exception) {}
    }

    private fun readAsset(name: String): String? = try {
        assets.open(name).bufferedReader().use { it.readText() }
    } catch (e: Exception) {
        null
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    override fun onBackPressed() {
        if (this::container.isInitialized && tabs.isNotEmpty() && web.canGoBack()) web.goBack()
        else super.onBackPressed()
    }

    override fun onDestroy() {
        for (t in tabs) { try { t.web.destroy() } catch (e: Exception) {} }
        tabs.clear()
        super.onDestroy()
    }
}
