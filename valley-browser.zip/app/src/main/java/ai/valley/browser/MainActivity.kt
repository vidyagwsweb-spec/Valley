package ai.valley.browser

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.Bitmap
import android.graphics.Outline
import android.graphics.Rect
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.PixelCopy
import android.view.MotionEvent
import android.view.animation.OvershootInterpolator
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.GeolocationPermissions
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewClientCompat
import java.io.ByteArrayInputStream
import java.net.URLEncoder

class MainActivity : Activity() {

    private inner class Tab(val web: WebView) {
        var title: String = "New Tab"
        var isPrivate: Boolean = false
    }

    private lateinit var container: FrameLayout
    private lateinit var urlView: TextView
    private lateinit var glow: PillGlowView
    private lateinit var assetLoader: WebViewAssetLoader
    private var sparkJs: String? = null
    private var readerJs: String? = null

    private val tabs = ArrayList<Tab>()
    private var current = 0
    private var privateCount = 0

    // protection is always on - there is nothing to switch off

    /** hosts that serve ads and trackers; a request to one of these is answered with nothing */
    private val blocked: HashSet<String> by lazy {
        RAW_BLOCKLIST.trim().lines().map { it.trim() }.filter { it.isNotEmpty() }.toHashSet()
    }
    private val active: Tab get() = tabs[current]
    private val web: WebView get() = active.web

    companion object {
        private const val HOST = "appassets.androidplatform.net"
        private const val START_URL = "https://$HOST/assets/index.html"

        private val RAW_BLOCKLIST = """
            doubleclick.net
            googlesyndication.com
            googleadservices.com
            google-analytics.com
            googletagmanager.com
            googletagservices.com
            adservice.google.com
            pagead2.googlesyndication.com
            facebook.net
            connect.facebook.net
            scorecardresearch.com
            quantserve.com
            quantcount.com
            moatads.com
            adsafeprotected.com
            adnxs.com
            adsrvr.org
            rubiconproject.com
            pubmatic.com
            casalemedia.com
            openx.net
            appnexus.com
            criteo.com
            criteo.net
            taboola.com
            outbrain.com
            revcontent.com
            mgid.com
            zergnet.com
            popads.net
            propellerads.com
            adcash.com
            exoclick.com
            juicyads.com
            trafficjunky.net
            media.net
            smartadserver.com
            teads.tv
            spotxchange.com
            tremorhub.com
            amazon-adsystem.com
            ads.yahoo.com
            adtech.de
            adform.net
            serving-sys.com
            flashtalking.com
            mathtag.com
            turn.com
            tapad.com
            bidswitch.net
            sharethrough.com
            triplelift.com
            indexexchange.com
            sovrn.com
            gumgum.com
            districtm.io
            yieldmo.com
            sonobi.com
            lijit.com
            krxd.net
            bluekai.com
            demdex.net
            omtrdc.net
            2o7.net
            everesttech.net
            adsymptotic.com
            agkn.com
            rlcdn.com
            tapfiliate.com
            branch.io
            appsflyer.com
            adjust.com
            kochava.com
            amplitude.com
            mixpanel.com
            segment.com
            segment.io
            heap.io
            hotjar.com
            hotjar.io
            fullstory.com
            clarity.ms
            inspectlet.com
            mouseflow.com
            smartlook.com
            luckyorange.com
            crazyegg.com
            optimizely.com
            vwo.com
            newrelic.com
            nr-data.net
            bugsnag.com
            rollbar.com
            sentry.io
            loggly.com
            chartbeat.com
            chartbeat.net
            parsely.com
            nr-data.net
            clicktale.net
            userreport.com
            mc.yandex.ru
            top-fwz1.mail.ru
            hb.wrating.com
            ctnsnet.com
            creativecdn.com
            adroll.com
            perfectaudience.com
            rebound.net
            retargeter.com
            steelhousemedia.com
            simpli.fi
            audienceproject.com
            narrative.io
            permutive.com
            id5-sync.com
            liadm.com
            pippio.com
            ads.linkedin.com
            analytics.tiktok.com
            business-api.tiktok.com
            ads.tiktok.com
            analytics.twitter.com
            static.ads-twitter.com
            ads.pinterest.com
            ads.reddit.com
            ads.snapchat.com
            sc-static.net
            tr.snapchat.com
        """
    }

    private fun isBlocked(host: String?): Boolean {
        if (host == null) return false
        val h = host.lowercase()
        if (blocked.contains(h)) return true
        // walk the parent domains instead of scanning the whole list per request
        var i = h.indexOf('.')
        while (i != -1) {
            if (blocked.contains(h.substring(i + 1))) return true
            i = h.indexOf('.', i + 1)
        }
        return false
    }

    private fun emptyResponse(): WebResourceResponse =
        WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        container = findViewById(R.id.web_container)
        urlView = findViewById(R.id.url)
        glow = findViewById(R.id.glow)

        assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        sparkJs = readAsset("spark.js")
        readerJs = readAsset("reader.js")


        val navBtn = findViewById<ImageButton>(R.id.back)
        navBtn.setOnClickListener {
            if (mode != Mode.BROWSING) {
                exitOverview()
                newTab(START_URL)
                return@setOnClickListener
            }
            if (navForward) {
                if (web.canGoForward()) web.goForward() else toast("No page to go forward to")
            } else {
                if (web.canGoBack()) web.goBack() else toast("No page to go back to")
            }
        }
        navBtn.setOnLongClickListener { showBackForward(); true }

        findViewById<ImageButton>(R.id.reload).setOnClickListener { web.reload() }
        urlView.setOnClickListener { editUrl() }
        findViewById<View>(R.id.urlScroll).setOnClickListener { editUrl() }
        try {
            (findViewById<View>(R.id.urlScroll) as android.widget.HorizontalScrollView)
                .isHorizontalFadingEdgeEnabled = true
        } catch (e: Exception) {}
        findViewById<ImageButton>(R.id.reader).setOnClickListener { toggleReader() }

        val settingsBtn = findViewById<ImageButton>(R.id.settings)
        settingsBtn.setOnClickListener {
            if (mode != Mode.BROWSING) showTabActions() else showPageMenu()
        }
        settingsBtn.setOnLongClickListener {
            if (mode != Mode.BROWSING) showTabActions() else showPageTools()
            true
        }

        listOf(R.id.back, R.id.reader, R.id.reload, R.id.settings).forEach { id ->
            pressable(findViewById(id))
        }
        pressable(findViewById(R.id.pill))

        // clip the frost layer to the pill's rounded shape
        val pillView = findViewById<View>(R.id.pill)
        pillView.clipToOutline = true
        pillView.outlineProvider = object : android.view.ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, view.height / 2f)
            }
        }
        enterToolbar()

        newTab(START_URL)
    }

    // ---------------------------------------------------------------- tabs

    @SuppressLint("SetJavaScriptEnabled")
    private fun buildWeb(private: Boolean = false): WebView {
        val w = WebView(this)
        w.settings.apply {
            javaScriptEnabled = true
            // a private tab writes no site storage at all
            domStorageEnabled = !private
            databaseEnabled = !private
            // hardening: no local file access, no popups, no saved form data
            allowFileAccess = false
            allowContentAccess = false
            allowFileAccessFromFileURLs = false
            allowUniversalAccessFromFileURLs = false
            javaScriptCanOpenWindowsAutomatically = false
            saveFormData = false
            if (android.os.Build.VERSION.SDK_INT >= 26) safeBrowsingEnabled = true
            useWideViewPort = true
            loadWithOverviewMode = true
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            // nothing is read from or written to the disk cache
            cacheMode = if (private) WebSettings.LOAD_NO_CACHE else WebSettings.LOAD_DEFAULT
            userAgentString = userAgentString.replace("; wv", "")
        }
        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            // third-party cookies are blocked per-WebView, so this really is per-tab
            // third-party cookies are blocked everywhere except where a site needs them
            setAcceptThirdPartyCookies(w, false)
        }

        w.webViewClient = object : WebViewClientCompat() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? {
                assetLoader.shouldInterceptRequest(request.url)?.let { return it }
                // never block the page itself, only what it pulls in
                if (!request.isForMainFrame && isBlocked(request.url.host)) return emptyResponse()
                return null
            }

            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean {
                val u = request.url
                // HTTPS only: upgrade plain http, refuse it if the host has no https
                if (u.scheme == "http") {
                    val secure = u.toString().replaceFirst("http://", "https://")
                    view.loadUrl(secure)
                    return true
                }
                return false
            }

            override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
                super.onPageStarted(view, url, favicon)
                if (view == web) setLoading(true)
            }

            override fun onPageFinished(view: WebView, url: String?) {
                super.onPageFinished(view, url)
                val tab = tabs.firstOrNull { it.web === view }
                if (url != null && tab != null && (tab.title == "New Tab" || tab.title.isBlank())) {
                    tab.title = prettyUrl(url)
                }
                if (view == web) {
                    setLoading(false)
                    if (url != null) {
                        showAddress(url)
                        urlView.alpha = 0.35f
                        urlView.animate().alpha(1f).setDuration(260).start()
                        pulsePill()
                        scheduleFrost()
                    }
                    refreshBack()
                }
                injectSpark(view, url)
                if (url != null && url.contains(HOST) && url.contains("index.html")) {
                    view.postDelayed({ if (view == web) syncWithHomepage() }, 220)
                }
            }
        }

        watchScroll(w)

        w.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                if (view == web) setLoading(newProgress in 1..99)
            }

            override fun onReceivedTitle(view: WebView?, title: String?) {
                val tab = tabs.firstOrNull { it.web === view }
                if (tab != null && !title.isNullOrBlank()) tab.title = title
            }

            override fun onGeolocationPermissionsShowPrompt(
                origin: String?,
                callback: GeolocationPermissions.Callback?
            ) {
                callback?.invoke(origin, origin != null && origin.contains(HOST), false)
            }
        }
        return w
    }

    /** a new tab gets its own WebView, so scroll position and form state survive switching */
    private fun newTab(url: String, private: Boolean = false) {
        val w = buildWeb(private)
        val tab = Tab(w)
        tab.isPrivate = private
        if (private) tab.title = "Private"
        privateCount += if (private) 1 else 0
        tabs.add(tab)
        current = tabs.size - 1
        attach()
        w.loadUrl(url)
        showAddress(url)
        refreshBack()
        if (mode != Mode.BROWSING) applyModeChrome()
    }

    private fun attach() {
        showBar()
        container.removeAllViews()
        val w = active.web
        container.addView(w, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        showAddress(w.url ?: START_URL)
        refreshBack()
    }

    private fun toggleReader() {
        val jsCode = readerJs
        if (jsCode == null) { readerUnavailable(); return }
        web.evaluateJavascript(jsCode) {
            web.evaluateJavascript("window.ulaaReaderToggle && window.ulaaReaderToggle()") { res ->
                if (res == null || res.contains("false")) readerUnavailable()
            }
        }
    }

    private fun readerUnavailable() {
        val card = menuCard()
        val msg = TextView(this).apply {
            text = "Reader mode is not available for this page."
            setTextColor(0xFFF6F0E8.toInt())
            textSize = 14f
            setLineSpacing(dp(3).toFloat(), 1f)
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        card.addView(msg)
        showCard(card, Align.LEFT)
    }

    private fun setLoading(loading: Boolean) {
        try { if (loading) glow.start() else glow.stop() } catch (e: Exception) {}
    }

    private var frostBusy = false
    private var frostRunnable: Runnable? = null

    /**
     * Capture what is under the pill, blur it, paint it in. This is the only way to get a real
     * frosted backdrop natively - Android has no backdrop-filter for views.
     */
    private fun refreshFrost() {
        if (android.os.Build.VERSION.SDK_INT < 26) return
        if (frostBusy) return
        val frost = findViewById<ImageView>(R.id.frost)
        val bar = findViewById<View>(R.id.toolbar)
        if (frost.width <= 0 || frost.height <= 0 || bar.height <= 0) return

        val loc = IntArray(2)
        frost.getLocationInWindow(loc)
        val rect = Rect(loc[0], loc[1], loc[0] + frost.width, loc[1] + frost.height)
        if (rect.left < 0 || rect.top < 0) return

        frostBusy = true
        val w = frost.width
        val h = frost.height
        val shot = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)

        // hide the bar for one frame so we do not photograph ourselves
        bar.alpha = 0f
        Handler(Looper.getMainLooper()).postDelayed({
            try {
                PixelCopy.request(window, rect, shot, { result ->
                    bar.alpha = 1f
                    frostBusy = false
                    if (result == PixelCopy.SUCCESS) {
                        try {
                            val small = Frost.blur(shot, 2, 8)
                            frost.setImageBitmap(Bitmap.createScaledBitmap(small, w, h, true))
                        } catch (e: Exception) {}
                    }
                }, Handler(Looper.getMainLooper()))
            } catch (e: Exception) {
                bar.alpha = 1f
                frostBusy = false
            }
        }, 48)
    }

    /** debounce: blur once the page stops moving */
    private fun scheduleFrost() {
        frostRunnable?.let { Handler(Looper.getMainLooper()).removeCallbacks(it) }
        val r = Runnable { refreshFrost() }
        frostRunnable = r
        Handler(Looper.getMainLooper()).postDelayed(r, 160)
    }

    private fun pulsePill() {
        val pill = findViewById<View>(R.id.pill)
        pill.animate().scaleX(1.035f).scaleY(1.035f).setDuration(130)
            .withEndAction {
                pill.animate().scaleX(1f).scaleY(1f).setDuration(340)
                    .setInterpolator(OvershootInterpolator(2.2f)).start()
            }.start()
    }

    private fun showAddress(url: String) {
        val label = addressLabel(url)
        if (active.isPrivate) {
            urlView.text = "\u25D0  " + label
            urlView.setTextColor(0xFFCBA8FF.toInt())
        } else {
            urlView.text = label
            urlView.setTextColor(0xFFF6F0E8.toInt())
        }
        try { findViewById<android.widget.HorizontalScrollView>(R.id.urlScroll).scrollTo(0, 0) } catch (e: Exception) {}
    }

    private fun switchTo(index: Int) {
        if (index !in tabs.indices) return
        current = index
        attach()
    }

    private fun closeTab(index: Int) {
        if (index !in tabs.indices) return
        val gone = tabs.removeAt(index)
        if (gone.isPrivate) privateCount = (privateCount - 1).coerceAtLeast(0)
        val needWipe = gone.isPrivate && privateCount == 0
        try { gone.web.destroy() } catch (e: Exception) {}
        if (tabs.isEmpty()) {
            newTab(START_URL)
        } else {
            current = index.coerceAtMost(tabs.size - 1)
            attach()
        }
        if (needWipe) wipePrivateSession()
        if (mode != Mode.BROWSING) applyModeChrome()
    }

    /**
     * Android gives the whole app one cookie jar, so a private tab cannot have a separate one.
     * What we can do: while private tabs are open nothing is written to site storage or the
     * disk cache, and when the last one closes the cookies and cache are destroyed.
     */
    private fun wipePrivateSession() {
        try {
            val cm = CookieManager.getInstance()
            cm.removeAllCookies(null)
            cm.flush()
        } catch (e: Exception) {}
        try { web.clearCache(true) } catch (e: Exception) {}
        try { web.clearFormData() } catch (e: Exception) {}
        try { web.clearHistory() } catch (e: Exception) {}
    }

    private fun refreshBack() {
        if (mode != Mode.BROWSING) { findViewById<ImageButton>(R.id.back).alpha = 1f; return }
        val can = if (navForward) web.canGoForward() else web.canGoBack()
        findViewById<ImageButton>(R.id.back).alpha = if (can) 1f else 0.35f
    }

    private fun addressLabel(url: String): String =
        if (url.contains(HOST) && url.contains("index.html")) "Search or enter website"
        else prettyUrl(url)

    private fun prettyUrl(url: String): String = try {
        if (url.contains(HOST)) "Valley" else java.net.URL(url).host.replace("^www\\.".toRegex(), "")
    } catch (e: Exception) {
        url
    }

    // ---------------------------------------------------------------- overview pages

    private fun overview(): FrameLayout = findViewById(R.id.overview)

    private fun enterOverview(kind: Mode, group: String? = null) {
        mode = kind
        filterGroup = group
        val box = overview()
        box.visibility = View.VISIBLE
        box.removeAllViews()
        box.addView(if (kind == Mode.TABS) buildTabsPage(group) else buildBookmarksPage())
        if (android.os.Build.VERSION.SDK_INT >= 31) {
            try {
                web.setRenderEffect(android.graphics.RenderEffect.createBlurEffect(
                    22f, 22f, android.graphics.Shader.TileMode.CLAMP))
            } catch (e: Exception) {}
        }
        box.alpha = 0f
        box.translationY = dp(18).toFloat()
        box.animate().alpha(1f).translationY(0f).setDuration(280)
            .setInterpolator(OvershootInterpolator(0.8f)).start()
        applyModeChrome()
    }

    private fun exitOverview() {
        if (mode == Mode.BROWSING) return
        mode = Mode.BROWSING
        filterGroup = null
        val box = overview()
        if (android.os.Build.VERSION.SDK_INT >= 31) {
            try { web.setRenderEffect(null) } catch (e: Exception) {}
        }
        box.animate().alpha(0f).translationY(dp(14).toFloat()).setDuration(180)
            .withEndAction { box.visibility = View.GONE; box.removeAllViews() }.start()
        applyModeChrome()
    }

    /** in an overview the pill counts tabs, the left circle adds one, the right one opens tab actions */
    private fun shrinkPill(shrink: Boolean) {
        try {
            val pill = findViewById<View>(R.id.pill)
            val lp = pill.layoutParams as LinearLayout.LayoutParams
            if (shrink) {
                lp.weight = 0f
                lp.width = LinearLayout.LayoutParams.WRAP_CONTENT
            } else {
                lp.weight = 1f
                lp.width = 0
            }
            pill.layoutParams = lp
        } catch (e: Exception) {}
    }

    private fun applyModeChrome() {
        val label = findViewById<TextView>(R.id.overviewLabel)
        val reader = findViewById<View>(R.id.reader)
        val reload = findViewById<View>(R.id.reload)
        val nav = findViewById<ImageButton>(R.id.back)
        val inOverview = mode != Mode.BROWSING

        urlView.visibility = if (inOverview) View.GONE else View.VISIBLE
        reader.visibility = if (inOverview) View.GONE else View.VISIBLE
        reload.visibility = if (inOverview) View.GONE else View.VISIBLE
        label.visibility = if (inOverview) View.VISIBLE else View.GONE

        shrinkPill(inOverview)
        if (inOverview) {
            label.text = if (mode == Mode.TABS) tabs.size.toString() + (if (tabs.size == 1) " tab" else " tabs")
                         else "Bookmarks"
            nav.setImageResource(R.drawable.ic_plus)
            nav.alpha = 1f
        } else {
            applyNavMode()
            refreshBack()
        }
    }

    private fun pageHeader(title: String): LinearLayout {
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(12))
        }
        head.addView(TextView(this).apply {
            text = title
            setTextColor(0xFFF6F0E8.toInt())
            textSize = 24f
            setTypeface(Typeface.create("serif", Typeface.ITALIC))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        head.addView(TextView(this).apply {
            text = "Done"
            setTextColor(0xFFE8622A.toInt())
            textSize = 13f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(12), dp(6), 0, dp(6))
            isClickable = true
            setOnClickListener { exitOverview() }
            pressable(this)
        })
        return head
    }

    private fun buildTabsPage(group: String?): View {
        val scroll = android.widget.ScrollView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
            isFillViewport = true
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, dp(96))
        }
        scroll.addView(col)
        col.addView(pageHeader(group ?: "Tabs"))

        val grid = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), 0, dp(14), 0)
        }
        col.addView(grid)

        var row: LinearLayout? = null
        var count = 0
        tabs.forEachIndexed { i, t ->
            if (group != null && !(groups.firstOrNull { it.first == group }?.second?.contains(t.web.url ?: "") ?: false)) return@forEachIndexed
            if (count % 2 == 0) {
                // a fresh row: assigned to a local first, because a captured var cannot be
                // smart-cast from LinearLayout? to LinearLayout inside this lambda
                val fresh = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    setPadding(0, dp(6), 0, dp(6))
                }
                grid.addView(fresh)
                row = fresh
            }
            val card = tabCard(t, i == current)
            val target = row
            if (target != null) {
                target.addView(card, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                    .also { it.setMargins(dp(6), 0, dp(6), 0) })
            }
            count++
        }
        if (count == 0) {
            col.addView(TextView(this).apply {
                text = "No tabs here yet."
                setTextColor(0xFF877E74.toInt())
                textSize = 13.5f
                setPadding(dp(20), dp(10), dp(20), dp(10))
            })
        }
        return scroll
    }

    private fun tabCard(t: Tab, active: Boolean): LinearLayout {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = getDrawable(
                if (active) R.drawable.card_glass_active else R.drawable.card_glass)
            isClickable = true
            setOnClickListener {
                switchTo(tabs.indexOf(t))
                exitOverview()
            }
            pressable(this)
        }
        card.addView(TextView(this).apply {
            text = (if (t.isPrivate) "\u25D0 " else "") + (t.title.take(28))
            setTextColor(if (t.isPrivate) 0xFFCBA8FF.toInt() else 0xFFF6F0E8.toInt())
            textSize = 13f
            maxLines = 2
            ellipsize = android.text.TextUtils.TruncateAt.END
        })
        card.addView(TextView(this).apply {
            text = prettyUrl(t.web.url ?: "")
            setTextColor(0xFF877E74.toInt())
            textSize = 11f
            setPadding(0, dp(6), 0, 0)
            maxLines = 1
        })
        return card
    }

    private fun buildBookmarksPage(): View {
        val scroll = android.widget.ScrollView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
            isFillViewport = true
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, dp(96))
        }
        scroll.addView(col)
        col.addView(pageHeader("Bookmarks"))

        val favs = (prefs().getString("list_favs", "") ?: "").split("\n").filter { it.isNotBlank() }
        val marks = (prefs().getString("list_bookmarks", "") ?: "").split("\n").filter { it.isNotBlank() }

        if (favs.isEmpty() && marks.isEmpty()) {
            col.addView(TextView(this).apply {
                text = "Nothing saved yet. Long-press \u22EF on a page and choose Add to Favourites."
                setTextColor(0xFF877E74.toInt())
                textSize = 13.5f
                setLineSpacing(dp(3).toFloat(), 1f)
                setPadding(dp(20), dp(10), dp(20), dp(10))
            })
            return scroll
        }
        if (favs.isNotEmpty()) {
            col.addView(sectionLabel("Favourites"))
            favs.forEach { col.addView(bookmarkRow(it, "\u2605")) }
        }
        if (marks.isNotEmpty()) {
            col.addView(sectionLabel("Bookmarks"))
            marks.forEach { col.addView(bookmarkRow(it, "\u25C6")) }
        }
        return scroll
    }

    private fun sectionLabel(text: String): TextView = TextView(this).apply {
        this.text = text.uppercase()
        setTextColor(0xFF877E74.toInt())
        textSize = 10f
        letterSpacing = 0.18f
        setPadding(dp(22), dp(18), dp(20), dp(6))
    }

    private fun bookmarkRow(url: String, mark: String): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(14), dp(14), dp(14))
            background = getDrawable(R.drawable.card_glass)
            isClickable = true
            setOnClickListener { exitOverview(); newTab(url) }
            pressable(this)
        }
        row.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            .also { it.setMargins(dp(16), dp(5), dp(16), dp(5)) }
        row.addView(TextView(this).apply {
            text = mark
            setTextColor(0xFFE8622A.toInt())
            textSize = 12f
            setPadding(0, 0, dp(12), 0)
        })
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(TextView(this).apply {
            text = prettyUrl(url)
            setTextColor(0xFFF6F0E8.toInt())
            textSize = 14.5f
            maxLines = 1
        })
        col.addView(TextView(this).apply {
            text = url
            setTextColor(0xFF877E74.toInt())
            textSize = 11f
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            setPadding(0, dp(3), 0, 0)
        })
        row.addView(col, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(TextView(this).apply {
            text = "\u00d7"
            setTextColor(0xFF877E74.toInt())
            textSize = 17f
            setPadding(dp(12), 0, dp(4), 0)
            isClickable = true
            setOnClickListener {
                val bucket = if (mark == "\u2605") "list_favs" else "list_bookmarks"
                val all = (prefs().getString(bucket, "") ?: "").split("\n").filter { it.isNotBlank() && it != url }
                prefs().edit().putString(bucket, all.joinToString("\n")).apply()
                enterOverview(Mode.BOOKMARKS)
            }
            pressable(this)
        })
        return row
    }

    // ---------------------------------------------------------------- url bar

    private fun editUrl() {
        val card = menuCard()
        val input = EditText(this).apply {
            setText(if (web.url == null || web.url!!.contains(HOST)) "" else web.url)
            setSingleLine(true)
            setTextColor(0xFFF6F0E8.toInt())
            setHintTextColor(0xFF877E74.toInt())
            hint = getString(R.string.url_hint)
            textSize = 16.5f
            setPadding(dp(16), dp(15), dp(16), dp(15))
            background = getDrawable(R.drawable.field_glass)
            setSelection(text.length)
        }
        card.addView(input, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        val go = TextView(this).apply {
            text = "Go"
            gravity = android.view.Gravity.CENTER
            setTextColor(0xFF150C07.toInt())
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(13), 0, dp(13))
            background = GradientDrawable().apply {
                cornerRadius = dp(16).toFloat()
                setColor(0xFFE8622A.toInt())
            }
            isClickable = true
            setOnClickListener {
                val typed = input.text.toString().trim()
                if (typed.isNotEmpty()) web.loadUrl(toUrl(typed))
                dismissLater()
            }
            pressable(this)
        }
        card.addView(go, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).also {
            it.setMargins(0, dp(10), 0, 0)
        })

        showCard(card, Align.FULL)
        input.requestFocus()
        input.postDelayed({
            try {
                val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showSoftInput(input, InputMethodManager.SHOW_IMPLICIT)
            } catch (e: Exception) {}
        }, 260)
    }

    private fun toUrl(input: String): String {
        val t = input.trim()
        if (t.startsWith("http://") || t.startsWith("https://") || t.startsWith("file://")) return t
        val looksLikeHost = !t.contains(" ") &&
                Regex("^[^\\s/?#]+\\.[a-z]{2,}([/?#].*)?$", RegexOption.IGNORE_CASE).containsMatchIn(t)
        return if (looksLikeHost) "https://$t"
        else "https://search.brave.com/search?q=" + URLEncoder.encode(t, "UTF-8")
    }

    // ---------------------------------------------------------------- menus

    private fun showPageMenu() {
        val card = menuCard()
        card.addView(menuRow(R.drawable.ic_share, "Share") { shareCurrent() })
        card.addView(menuRow(R.drawable.ic_star, "Add to Favourites") { saveLink("favs") })
        card.addView(menuRow(R.drawable.ic_bookmark, "Add Bookmark to\u2026") { saveLink("bookmarks") })
        card.addView(menuDivider())
        card.addView(menuRow(R.drawable.ic_plus, "New Tab") { newTab(START_URL) })
        card.addView(menuRow(R.drawable.ic_mask, "New Private Tab") { privateTab() })
        card.addView(twoUpRow())
        showCard(card, Align.RIGHT)
    }

    private fun showPageTools() {
        val card = menuCard()
        card.addView(menuRow(R.drawable.ic_translate, "Translate page") { js("window.ulaaTranslate && window.ulaaTranslate()") })
        card.addView(menuRow(R.drawable.ic_eraser, "Eraser") { js("window.ulaaEraser && window.ulaaEraser()") })
        card.addView(menuRow(R.drawable.ic_summary, "Summarise page") { js("window.ulaaSummarise && window.ulaaSummarise()") })
        card.addView(menuDivider())
        card.addView(menuRow(R.drawable.ic_smart, "Smart search") { showSmartSearch() })
        card.addView(menuRow(R.drawable.ic_copy, "Copy link") {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("link", web.url ?: ""))
            toast("Link copied")
        })
        card.addView(menuRow(R.drawable.ic_home, "Home") { web.loadUrl(START_URL) })
        showCard(card, Align.RIGHT)
    }

    private fun showBackForward() {
        val card = menuCard()

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(2), dp(10), dp(2), dp(4))
        }
        row.addView(arrowCell(R.drawable.ic_chevron_left, "Back", !navForward) {
            navForward = false
            applyNavMode()
            dismissLater()
        }, weight())
        row.addView(arrowCell(R.drawable.ic_chevron_right, "Forward", navForward) {
            navForward = true
            applyNavMode()
            dismissLater()
        }, weight())
        card.addView(row)

        // one wide button underneath, showing whichever direction the circle is set to
        val wide = TextView(this).apply {
            text = if (navForward) "Forward" else "Back"
            gravity = android.view.Gravity.CENTER
            setTextColor(0xFFF6F0E8.toInt())
            textSize = 14f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(12), 0, dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dp(999).toFloat()
                setColor(0x3DFFFFFF)
            }
            isClickable = true
            setOnClickListener {
                navForward = !navForward
                applyNavMode()
                dismissLater()
            }
            pressable(this)
        }
        card.addView(wide, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            .also { it.setMargins(dp(10), dp(6), dp(10), dp(12)) })

        showCard(card, Align.LEFT)
    }

    private fun arrowCell(icon: Int, label: String, selected: Boolean, onClick: () -> Unit): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = android.view.Gravity.CENTER
            isClickable = true
            setPadding(0, dp(10), 0, dp(8))
            setOnClickListener { onClick() }
            pressable(this)
        }
        box.addView(ImageView(this).apply {
            setImageResource(icon)
            layoutParams = LinearLayout.LayoutParams(dp(24), dp(24))
        })
        // the label sits directly under its arrow, full brightness either way
        box.addView(TextView(this).apply {
            text = label
            setTextColor(if (selected) 0xFFF6F0E8.toInt() else 0xFFB3A89C.toInt())
            textSize = 12.5f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(6), 0, 0)
        })
        return box
    }

    private fun privateTab() {
        val card = menuCard()
        card.addView(titleBlock("New Private Tab",
            "No site storage, no cache, third-party cookies off. When you close the last private " +
            "tab, every cookie is wiped \u2014 which also signs you out of your normal tabs, because " +
            "Android shares one cookie jar."))
        card.addView(primaryButton("Open private tab", 0xFF7B3FF2.toInt()) {
            dismissLater(); newTab(START_URL, true)
        })
        showCard(card, Align.RIGHT)
    }

    private fun titleBlock(title: String, body: String): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(6))
        }
        box.addView(TextView(this).apply {
            text = title
            setTextColor(0xFFF6F0E8.toInt())
            textSize = 16.5f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, 0, 0, dp(8))
        })
        box.addView(TextView(this).apply {
            text = body
            setTextColor(0xFFB3A89C.toInt())
            textSize = 13f
            setLineSpacing(dp(3).toFloat(), 1f)
        })
        return box
    }

    private fun primaryButton(label: String, colour: Int, onClick: () -> Unit): TextView {
        val b = TextView(this).apply {
            text = label
            gravity = android.view.Gravity.CENTER
            setTextColor(0xFF150C07.toInt())
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(13), 0, dp(13))
            background = GradientDrawable().apply {
                cornerRadius = dp(16).toFloat(); setColor(colour)
            }
            isClickable = true
            setOnClickListener { onClick() }
            pressable(this)
        }
        b.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            .also { it.setMargins(dp(10), dp(10), dp(10), dp(8)) }
        return b
    }

    private fun showTabActions() {
        val card = menuCard()

        // existing groups sit where the reference image keeps its saved groups
        groups.forEach { g ->
            card.addView(menuRow(R.drawable.ic_group, g.first) {
                dismissLater()
                enterOverview(Mode.TABS, g.first)
            })
        }
        if (groups.isNotEmpty()) card.addView(menuDivider())

        card.addView(menuRow(R.drawable.ic_mask, "Private") { dismissLater(); exitOverview(); newTab(START_URL, true) })
        card.addView(menuRow(R.drawable.ic_tabs,
            tabs.size.toString() + (if (tabs.size == 1) " Tab" else " Tabs") + "   \u2713") {
            dismissLater()
            enterOverview(Mode.TABS)
        })

        card.addView(menuDivider())

        card.addView(menuRow(R.drawable.ic_chevron_left, "Close All " + tabs.size + " Tabs", destructive = true) {
            dismissLater()
            closeAllTabs()
        })
        card.addView(menuRow(R.drawable.ic_chevron_left, "Close This Tab", destructive = true) {
            dismissLater()
            closeTab(current)
            if (tabs.isNotEmpty()) enterOverview(Mode.TABS) else exitOverview()
        })

        card.addView(menuRow(R.drawable.ic_group, "Move to Tab Group", chevron = true) {
            dismissLater(); showMoveToGroup()
        })
        card.addView(menuDivider())
        card.addView(menuRow(R.drawable.ic_mask, "New Private Tab") { dismissLater(); exitOverview(); newTab(START_URL, true) })
        card.addView(menuRow(R.drawable.ic_plus, "New Tab") { dismissLater(); exitOverview(); newTab(START_URL) })
        card.addView(menuRow(R.drawable.ic_group, "New Tab Group") { dismissLater(); newGroupPrompt() })

        showCard(card, Align.RIGHT)
    }

    private fun closeAllTabs() {
        for (i in tabs.indices.reversed()) {
            val t = tabs.removeAt(i)
            if (t.isPrivate) privateCount = (privateCount - 1).coerceAtLeast(0)
            try { t.web.destroy() } catch (e: Exception) {}
        }
        newTab(START_URL)
        enterOverview(Mode.TABS)
    }

    private fun showMoveToGroup() {
        val card = menuCard()
        val url = web.url ?: START_URL
        if (groups.isEmpty()) {
            card.addView(menuRow(R.drawable.ic_group, "No groups yet \u2014 create one") { dismissLater(); newGroupPrompt() })
        } else {
            groups.forEach { g ->
                card.addView(menuRow(R.drawable.ic_group, g.first) {
                    dismissLater()
                    if (!g.second.contains(url)) g.second.add(url)
                    toast("Moved to " + g.first)
                })
            }
        }
        showCard(card, Align.RIGHT)
    }

    private fun newGroupPrompt() {
        val card = menuCard()
        val input = EditText(this).apply {
            hint = "Group name"
            setHintTextColor(0xFF877E74.toInt())
            setTextColor(0xFFF6F0E8.toInt())
            textSize = 16.5f
            setSingleLine(true)
            setPadding(dp(16), dp(15), dp(16), dp(15))
            background = getDrawable(R.drawable.field_glass)
        }
        card.addView(input)
        card.addView(primaryButton("Create group", 0xFFE8622A.toInt()) {
            val name = input.text.toString().trim()
            if (name.isNotEmpty()) {
                val existing = groups.firstOrNull { it.first == name }
                val urls = existing?.second ?: mutableListOf<String>().also { groups.add(name to it) }
                val url = web.url
                if (url != null && !urls.contains(url)) urls.add(url)
                toast("Created " + name)
                dismissLater()
                enterOverview(Mode.TABS)
            } else {
                toast("Give the group a name")
            }
        })
        showCard(card, Align.RIGHT)
        input.requestFocus()
        input.postDelayed({
            try {
                val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showSoftInput(input, InputMethodManager.SHOW_IMPLICIT)
            } catch (e: Exception) {}
        }, 260)
    }

    private fun showTabs() {
        val card = menuCard()

        tabs.forEachIndexed { i, t ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(12), dp(10), dp(12))
                isClickable = true
                setOnClickListener {
                    switchTo(i)
                    dismissLater()
                }
                pressable(this)
            }
            val dot = TextView(this).apply {
                text = if (i == current) "\u25CF" else "\u25CB"
                setTextColor(if (i == current) 0xFFE8622A.toInt() else 0x88FFFFFF.toInt())
                textSize = 12f
                setPadding(0, 0, dp(10), 0)
            }
            val label = TextView(this).apply {
                text = (if (t.isPrivate) "\u25D0  " else "") + t.title
                setTextColor(if (t.isPrivate) 0xFFCBA8FF.toInt() else 0xFFF6F0E8.toInt())
                textSize = 14.5f
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            val close = TextView(this).apply {
                text = "\u00d7"
                setTextColor(0x99FFFFFF.toInt())
                textSize = 18f
                setPadding(dp(10), 0, dp(6), 0)
                isClickable = true
                setOnClickListener {
                    dismissLater()
                    closeTab(i)
                }
                pressable(this)
            }
            row.addView(dot); row.addView(label); row.addView(close)
            card.addView(row)
        }

        card.addView(menuDivider())
        card.addView(menuRow(R.drawable.ic_plus, "New Tab") { dismissLater(); newTab(START_URL) })
        card.addView(menuRow(R.drawable.ic_mask, "New Private Tab") { dismissLater(); newTab(START_URL, true) })
        showCard(card, Align.LEFT)
    }

    private fun showBookmarks() {
        val favs = (prefs().getString("list_favs", "") ?: "").split("\n").filter { it.isNotBlank() }
        val marks = (prefs().getString("list_bookmarks", "") ?: "").split("\n").filter { it.isNotBlank() }
        val card = menuCard()
        if (favs.isEmpty() && marks.isEmpty()) {
            val empty = TextView(this).apply {
                text = "Nothing saved yet. Long-press \u22EF and choose Add to Favourites."
                setTextColor(0xFF877E74.toInt())
                textSize = 13.5f
                setPadding(dp(14), dp(16), dp(14), dp(16))
            }
            card.addView(empty)
            showCard(card, Align.RIGHT)
            return
        }
        favs.forEach { url -> card.addView(linkRow("\u2605", url)) }
        marks.forEach { url -> card.addView(linkRow("\u25C6", url)) }
        showCard(card, Align.RIGHT)
    }

    private fun linkRow(mark: String, url: String): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(13), dp(12), dp(13))
            isClickable = true
            setOnClickListener { dismissLater(); newTab(url) }
            pressable(this)
        }
        row.addView(TextView(this).apply {
            text = mark
            setTextColor(0xFFE8622A.toInt())
            textSize = 13f
            setPadding(0, 0, dp(12), 0)
        })
        row.addView(TextView(this).apply {
            text = prettyUrl(url)
            setTextColor(0xFFF6F0E8.toInt())
            textSize = 14.5f
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        })
        return row
    }

    private fun showSmartSearch() {
        val card = menuCard()
        card.addView(titleBlock("Smart search",
            "When on, a query that names a site opens that site's own search \u2014 " +
            "\u201cprice of oneplus nord ce6 on Flipkart\u201d lands on Flipkart's results. " +
            "When off, everything goes to Brave exactly as typed."))
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(10), 0, dp(10), dp(10))
        }
        row.addView(primaryButton("Turn on", 0xFFE8622A.toInt()) {
            js("window.ulaaSmartSet && window.ulaaSmartSet(true)"); dismissLater()
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(primaryButton("Turn off", 0xFF3A332D.toInt()) {
            js("window.ulaaSmartSet && window.ulaaSmartSet(false)"); dismissLater()
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        card.addView(row)
        showCard(card, Align.RIGHT)
    }

    // ---------------------------------------------------------------- menu pieces

    private fun twoUpRow(): LinearLayout {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(bigTile(R.drawable.ic_bookmarks, "Bookmarks") { dismissLater(); enterOverview(Mode.BOOKMARKS) }, weight())
        row.addView(bigTile(R.drawable.ic_tabs, "All Tabs") { dismissLater(); enterOverview(Mode.TABS) }, weight())
        return row
    }

    private fun weight() = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)

    private fun bigTile(icon: Int, label: String, onClick: () -> Unit): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = android.view.Gravity.CENTER
            setPadding(0, dp(10), 0, dp(12))
            isClickable = true
            setOnClickListener { onClick() }
        }
        box.addView(ImageView(this).apply {
            setImageResource(icon)
            layoutParams = LinearLayout.LayoutParams(dp(22), dp(22))
        })
        box.addView(TextView(this).apply {
            text = label
            setTextColor(0xFFEDE7E0.toInt())
            textSize = 11.5f
            gravity = android.view.Gravity.CENTER
            setPadding(0, dp(6), 0, 0)
        })
        return box
    }

    private fun dirTile(icon: Int, label: String, enabled: Boolean, onClick: () -> Unit): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = android.view.Gravity.CENTER
            isClickable = true
            alpha = if (enabled) 1f else 0.35f
            setOnClickListener { onClick() }
        }
        box.addView(ImageView(this).apply {
            setImageResource(icon)
            layoutParams = LinearLayout.LayoutParams(dp(22), dp(22))
        })
        box.addView(TextView(this).apply {
            text = label
            setTextColor(0xFFEDE7E0.toInt())
            textSize = 12.5f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(6), 0, 0)
        })
        return box
    }

    private fun segment(label: String, active: Boolean, onClick: () -> Unit): TextView {
        val tv = TextView(this)
        tv.text = label
        tv.gravity = android.view.Gravity.CENTER
        tv.textSize = 13f
        tv.setPadding(0, dp(9), 0, dp(9))
        tv.setTextColor(if (active) 0xFFF6F0E8.toInt() else 0x99FFFFFF.toInt())
        if (active) {
            tv.background = GradientDrawable().apply {
                cornerRadius = dp(999).toFloat(); setColor(0x33FFFFFF)
            }
        }
        tv.isClickable = true
        tv.setOnClickListener { onClick() }
        return tv
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    // ---- motion: the app should feel like the pill, not like a settings screen ----

    /** press feedback: squash on touch down, spring back on release */
    private fun pressable(v: View) {
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN ->
                    view.animate().scaleX(0.92f).scaleY(0.92f)
                        .setDuration(90).setInterpolator(null).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    view.animate().scaleX(1f).scaleY(1f)
                        .setDuration(240).setInterpolator(OvershootInterpolator(2.6f)).start()
            }
            false
        }
    }

    /** the toolbar rises into place on launch */
    private fun enterToolbar() {
        val bar = findViewById<View>(R.id.toolbar)
        bar.translationY = dp(56).toFloat()
        bar.alpha = 0f
        bar.animate().translationY(0f).alpha(1f)
            .setStartDelay(140).setDuration(560)
            .setInterpolator(OvershootInterpolator(1.5f)).start()
    }

    private var barHidden = false

    /** the left circle does one thing at a time: back, or forward, whichever you picked */
    private var navForward = false

    private enum class Mode { BROWSING, TABS, BOOKMARKS }
    private var mode = Mode.BROWSING
    private var filterGroup: String? = null

    /** tab groups: a name and the pages that belong to it */
    private val groups = ArrayList<Pair<String, MutableList<String>>>()

    /** scrolling down tucks the toolbar away, scrolling up springs it back */
    private fun watchScroll(w: WebView) {
        w.setOnScrollChangeListener { _, _, y, _, oldY ->
            val dy = y - oldY
            if (dy > 12 && !barHidden) hideBar() else if (dy < -12 && barHidden) showBar()
            scheduleFrost()
        }
    }

    private fun hideBar() {
        barHidden = true
        val bar = findViewById<View>(R.id.toolbar)
        bar.animate().translationY((bar.height + dp(28)).toFloat()).alpha(0f)
            .setDuration(240).setInterpolator(android.view.animation.AccelerateInterpolator(1.4f)).start()
    }

    private fun showBar() {
        if (!barHidden) return
        barHidden = false
        val bar = findViewById<View>(R.id.toolbar)
        bar.animate().translationY(0f).alpha(1f)
            .setDuration(380).setInterpolator(OvershootInterpolator(1.6f)).start()
        scheduleFrost()
        // the same spring the spark pill gives when it expands
        val pill = findViewById<View>(R.id.pill)
        pill.animate().scaleX(1.045f).scaleY(1.045f).setDuration(150)
            .withEndAction {
                pill.animate().scaleX(1f).scaleY(1f).setDuration(360)
                    .setInterpolator(OvershootInterpolator(2.4f)).start()
            }.start()
    }

    /** sheets rise from the bottom with a spring, the way the pill's menus do */
    private fun animateSheetIn(card: View) {
        card.alpha = 0f
        card.translationY = dp(46).toFloat()
        card.scaleX = 0.97f
        card.scaleY = 0.97f
        card.animate().alpha(1f).translationY(0f).scaleX(1f).scaleY(1f)
            .setDuration(420).setInterpolator(OvershootInterpolator(1.1f)).start()
    }

    /** rows fade up one after another */
    private fun staggerRows(card: LinearLayout) {
        for (i in 0 until card.childCount) {
            val child = card.getChildAt(i)
            child.alpha = 0f
            child.translationY = dp(10).toFloat()
            child.animate().alpha(1f).translationY(0f)
                .setStartDelay((70L + i * 38L))
                .setDuration(300)
                .setInterpolator(android.view.animation.DecelerateInterpolator()).start()
        }
    }

    private fun menuCard(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(6), dp(6), dp(6), dp(6))
        background = getDrawable(R.drawable.sheet_glass)
        clipToOutline = false
    }

    private fun menuDivider(): View = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(1)).also { it.setMargins(dp(49), dp(6), dp(14), dp(6)) }
        setBackgroundColor(0x24FFFFFF)
    }

    private fun menuRow(
        icon: Int,
        label: String,
        chevron: Boolean = false,
        destructive: Boolean = false,
        onClick: () -> Unit
    ): LinearLayout {
        val tint = if (destructive) 0xFFFF453A.toInt() else 0xFFF6F0E8.toInt()
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(13), dp(14), dp(13))
            isClickable = true
            setOnClickListener { onClick() }
        }
        row.addView(ImageView(this).apply {
            setImageResource(icon)
            if (destructive) setColorFilter(0xFFFF453A.toInt())
            layoutParams = LinearLayout.LayoutParams(dp(20), dp(20))
        })
        row.addView(TextView(this).apply {
            text = label
            setTextColor(tint)
            textSize = 16f
            setPadding(dp(15), 0, 0, 0)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        if (chevron) {
            row.addView(ImageView(this).apply {
                setImageResource(R.drawable.ic_chevron_right)
                alpha = 0.45f
                layoutParams = LinearLayout.LayoutParams(dp(15), dp(15))
            })
        }
        // press highlight, the way iOS dims a row under the finger
        row.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> view.setBackgroundResource(R.drawable.row_press)
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> view.background = null
            }
            false
        }
        return row
    }

    private var lastDialog: Dialog? = null

    enum class Align { LEFT, RIGHT, FULL }

    private fun showCard(card: LinearLayout, align: Align = Align.RIGHT) {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE)
        val wrap = FrameLayout(this)
        val sidePad = dp(12)
        wrap.setPadding(sidePad, 0, sidePad, dp(12))

        val screen = resources.displayMetrics.widthPixels
        val narrow = Math.min(dp(300), screen - dp(56))
        val cardParams = FrameLayout.LayoutParams(
            if (align == Align.FULL) FrameLayout.LayoutParams.MATCH_PARENT else narrow,
            FrameLayout.LayoutParams.WRAP_CONTENT)
        cardParams.gravity = when (align) {
            Align.LEFT -> android.view.Gravity.START or android.view.Gravity.BOTTOM
            Align.RIGHT -> android.view.Gravity.END or android.view.Gravity.BOTTOM
            Align.FULL -> android.view.Gravity.CENTER_HORIZONTAL or android.view.Gravity.BOTTOM
        }
        wrap.addView(card, cardParams)
        dialog.setContentView(wrap)
        dialog.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            addFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND)
            setDimAmount(0.55f)
            val lp = attributes
            lp.width = android.view.WindowManager.LayoutParams.MATCH_PARENT
            lp.height = android.view.WindowManager.LayoutParams.WRAP_CONTENT
            lp.gravity = android.view.Gravity.BOTTOM
            attributes = lp
        }
        dialog.setCanceledOnTouchOutside(true)
        lastDialog = dialog
        dialog.setOnShowListener {
            animateSheetIn(card)
            staggerRows(card)
        }
        dialog.show()
    }

    private fun dismissLater() {
        val d = lastDialog
        lastDialog = null
        try { d?.dismiss() } catch (e: Exception) {}
    }

    // ---------------------------------------------------------------- misc

    private fun shareCurrent() {
        val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(android.content.Intent.EXTRA_TEXT, web.url ?: "")
        }
        startActivity(android.content.Intent.createChooser(intent, "Share"))
    }

    private fun prefs(): SharedPreferences = getSharedPreferences("valley", MODE_PRIVATE)

    private fun saveLink(bucket: String) {
        val url = web.url ?: return
        val key = "list_$bucket"
        val all = (prefs().getString(key, "") ?: "").split("\n").filter { it.isNotBlank() }.toMutableList()
        if (all.contains(url)) { toast("Already saved"); return }
        all.add(0, url)
        prefs().edit().putString(key, all.joinToString("\n")).apply()
        toast(if (bucket == "favs") "Added to Favourites" else "Added to Bookmarks")
    }

    private fun js(code: String) {
        try { web.evaluateJavascript(code, null) } catch (e: Exception) {}
    }

    /**
     * The app saves bookmarks in Android storage; the homepage keeps its own list in the page's
     * localStorage. On the start page the two are merged, so everything you saved shows up in
     * Favourites there, and anything you delete there comes back to the app.
     */
    private fun syncWithHomepage() {
        val favs = (prefs().getString("list_favs", "") ?: "").split("\n").filter { it.isNotBlank() }
        val marks = (prefs().getString("list_bookmarks", "") ?: "").split("\n").filter { it.isNotBlank() }
        val all = (favs + marks).distinct()
        if (all.isEmpty()) {
            web.evaluateJavascript("window.ulaaRefresh && window.ulaaRefresh()", null)
            return
        }
        val arr = org.json.JSONArray(all).toString()
        val code = "(function(){try{" +
                "var add=" + arr + ";" +
                "var cur=[];try{cur=JSON.parse(localStorage.getItem('hp.favs')||'[]');}catch(e){cur=[];}" +
                "var have={};cur.forEach(function(x){if(x&&x.u)have[x.u]=1;});" +
                "add.forEach(function(u){if(!have[u])cur.push({u:u,n:''});});" +
                "localStorage.setItem('hp.favs',JSON.stringify(cur));" +
                "return cur.map(function(x){return (x&&x.u)||'';}).filter(Boolean).join('\\n');" +
                "}catch(e){return '';}})()"

        web.evaluateJavascript(code) { res ->
            try {
                val merged = org.json.JSONTokener(res).nextValue() as? String
                if (!merged.isNullOrBlank()) {
                    // the page is now the single list: everything is a favourite there
                    prefs().edit()
                        .putString("list_favs", merged)
                        .putString("list_bookmarks", "")
                        .apply()
                }
            } catch (e: Exception) {}
            web.evaluateJavascript("window.ulaaRefresh && window.ulaaRefresh()", null)
        }
    }

    private fun injectSpark(view: WebView, url: String?) {
        val code = sparkJs ?: return
        if (url == null || url.contains(HOST)) return
        try {
            view.evaluateJavascript(code) {
                try { view.evaluateJavascript("window.ulaaHidePill && window.ulaaHidePill()", null) } catch (e: Exception) {}
            }
        } catch (e: Exception) {}
    }

    private fun readAsset(name: String): String? = try {
        assets.open(name).bufferedReader().use { it.readText() }
    } catch (e: Exception) {
        null
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    override fun onBackPressed() {
        if (this::container.isInitialized && tabs.isNotEmpty() && web.canGoBack()) web.goBack()
        else super.onBackPressed()
    }

    override fun onDestroy() {
        for (t in tabs) { try { t.web.destroy() } catch (e: Exception) {} }
        tabs.clear()
        super.onDestroy()
    }
}
