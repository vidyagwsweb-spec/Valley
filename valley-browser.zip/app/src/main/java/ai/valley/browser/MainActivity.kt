package ai.valley.browser

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.webkit.CookieManager
import android.webkit.GeolocationPermissions
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ProgressBar
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewClientCompat

class MainActivity : Activity() {

    private lateinit var web: WebView
    private lateinit var bar: EditText
    private lateinit var progress: ProgressBar
    private lateinit var assetLoader: WebViewAssetLoader
    private var sparkJs: String? = null

    companion object {
        // the homepage, served from app assets over a real https origin so that
        // localStorage, geolocation and fetches all behave like a normal site
        private const val HOST = "appassets.androidplatform.net"
        private const val START_URL = "https://$HOST/assets/index.html"
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        web = findViewById(R.id.web)
        bar = findViewById(R.id.bar)
        progress = findViewById(R.id.progress)

        assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        sparkJs = readAsset("spark.js")

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            useWideViewPort = true
            loadWithOverviewMode = true
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            cacheMode = WebSettings.LOAD_DEFAULT
            // a plain browser UA: some sites refuse to serve a WebView
            userAgentString = userAgentString.replace("; wv", "")
        }

        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(web, true)
        }

        web.webViewClient = object : WebViewClientCompat() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? = assetLoader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean = false

            override fun onPageFinished(view: WebView, url: String?) {
                super.onPageFinished(view, url)
                progress.visibility = View.GONE
                if (url != null) bar.setText(url)
                injectSpark(url)
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progress.progress = newProgress
                progress.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
            }

            override fun onGeolocationPermissionsShowPrompt(
                origin: String?,
                callback: GeolocationPermissions.Callback?
            ) {
                // the weather on the start page asks for this; nothing else does
                val ok = origin != null && origin.contains(HOST)
                callback?.invoke(origin, ok, false)
            }
        }

        bar.setOnEditorActionListener { _, actionId, event ->
            val isGo = actionId == EditorInfo.IME_ACTION_GO ||
                    (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER)
            if (isGo) {
                val typed = bar.text.toString().trim()
                if (typed.isNotEmpty()) {
                    web.loadUrl(toUrl(typed))
                    bar.clearFocus()
                    hideKeyboard()
                }
                true
            } else false
        }

        findViewById<ImageButton>(R.id.back).setOnClickListener {
            if (web.canGoBack()) web.goBack()
        }
        findViewById<ImageButton>(R.id.forward).setOnClickListener {
            if (web.canGoForward()) web.goForward()
        }
        findViewById<ImageButton>(R.id.home).setOnClickListener {
            web.loadUrl(START_URL)
        }

        web.loadUrl(START_URL)
    }

    /** the same routing the page uses: an address goes there, anything else searches */
    private fun toUrl(input: String): String {
        val t = input.trim()
        if (t.startsWith("http://") || t.startsWith("https://") || t.startsWith("file://")) return t
        val looksLikeHost = !t.contains(" ") &&
                Regex("^[^\\s/?#]+\\.[a-z]{2,}([/?#].*)?$", RegexOption.IGNORE_CASE).containsMatchIn(t)
        return if (looksLikeHost) "https://$t"
        else "https://search.brave.com/search?q=" + java.net.URLEncoder.encode(t, "UTF-8")
    }

    /** the pill, injected into every page except our own start page */
    private fun injectSpark(url: String?) {
        val js = sparkJs ?: return
        if (url == null) return
        if (url.contains(HOST)) return          // never over the homepage itself
        web.evaluateJavascript(js, null)
    }

    private fun readAsset(name: String): String? = try {
        assets.open(name).bufferedReader().use { it.readText() }
    } catch (e: Exception) {
        null
    }

    private fun hideKeyboard() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
        imm.hideSoftInputFromWindow(bar.windowToken, 0)
    }

    override fun onBackPressed() {
        if (this::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
