Valley v15 — reader/reload symbols and direct pill navigation

- Replaced the reader-mode symbol with the requested webpage/reading-lines glyph: a rounded rectangular page outline with horizontal lines beneath it.
- Replaced the reload symbol with a cleaner clockwise circular refresh arrow matching the supplied reference.
- Updated both the HTML toolbar SVGs and Android drawable resources so the symbols remain consistent wherever the toolbar implementation is used.
- Made the left navigation pill explicitly consume its click event and invoke the native back/forward action directly; it no longer relies on opening the navigation panel to navigate. The selected direction still follows the existing Back/Forward mode.
- Added explicit preventDefault/stopPropagation to reader and reload controls to avoid parent click handling interfering with their actions.

Validation: inline toolbar JavaScript passes `node --check`. The Android APK has not been compiled or tested on-device in this environment.


## Dark toolbar strip fix
- Fixed the native `resizeToolbarWeb()` override: collapsed toolbar WebView now uses 54dp instead of 78dp, matching the layout height.
- Explicitly clear the toolbar WebView background during setup and resizing so the rectangular WebView surface remains transparent.
- Expanded height remains 360dp only while panels are open.
- Source-level change; validate in the generated APK on-device.
