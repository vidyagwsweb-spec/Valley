# Valley

An Android browser shell around WebView: your homepage as the start page, and a bottom toolbar
in the shape of the iOS 26 pill row.

```
( ← )   [ 📖   url.com   ⟳ ]   ( ⋯ )
```

- **( ← )** goes back. **Long-press it** to choose Back or Forward — two arrows with their labels,
  and only the chosen direction stays on the button, so a tap always does the one you picked.
- **📖** is reader mode: it pulls the article out of the page and shows it on warm paper, with
  serif type and no clutter. Tap again to close.
- the address in the middle — tap it to type
- **⟳** reloads
- panels are narrow and open on the side of the pill they belong to — the ⋯ menu on the right,
  tabs and back/forward on the left

**Overview pages.** ⋯ → All Tabs, or ⋯ → Bookmarks, opens a full page instead of a dialog:

- **Tabs** — a two-column grid of tab cards, the active one outlined in orange. Tap to switch.
- **Bookmarks** — favourites and bookmarks as links with their URL underneath, × to remove.

While an overview is open the toolbar changes: the pill shows the tab count (`7 tabs`), the left
circle becomes **+** (new tab), and ⋯ opens the tab actions panel — Private, N Tabs, Close All,
Close This Tab, Move to Tab Group, New Private Tab, New Tab, New Tab Group. Tab groups you create
appear at the top of that panel, and tapping one filters the overview to its pages.
- **( ⋯ )** opens the Safari-style menu: Share, Add to Favourites, Add Bookmark to…, New Tab,
  New Private Tab, and a Bookmarks / All Tabs pair
- **long-press ( ⋯ )** opens the page tools: Translate, Eraser, Summarise, Smart search, Copy
  link, Home
- **long-press ( ← )** opens the Back / Forward popover with a segmented control showing which
  direction is live

The page tools that used to float over the page as the Valley pill now live behind the long
press. The pill is still injected on every site — it just hides itself, and the menu calls into it.

## Build it

1. Put `valley-browser.zip` in the root of your repository.
2. Add `.github/workflows/build.yml` (the small workflow).
3. Actions runs, unzips, builds, and hands you `valley-debug-apk`.

## What it does

- **Start page** — your homepage, served from inside the app over a real `https://` origin, so
  `localStorage`, geolocation and `fetch` behave as they do on GitHub Pages. History, Security and
  About are views inside that same single file, not separate pages.
- **Tabs** — one WebView per tab. Switching detaches the old one and attaches the new one, so
  scroll position, form state and video all survive. Closing a tab destroys its WebView.
- **Page tools** — translate, eraser and the AI summary are still the pill's code, driven from
  the native menu via `window.ulaaTranslate()`, `ulaaEraser()`, `ulaaSummarise()`.
- **Pill search routing** — the floating pill now uses Valley's smart-routing rules: direct URLs,
  `open` / `visit` commands, typo-tolerant known-site navigation, and site-specific search routes
  for supported services. Ordinary queries still go to Brave. The smart-search preference is read
  from the current page when available, then saved as the app fallback.
- **No ads, no telemetry, no accounts.**

## Security (always on, not configurable)

There is no switch to turn these off. They are part of how the browser works:

- **Ads and trackers blocked** — requests to ~130 ad/tracker hosts are answered with an empty
  body. Subresources only; the page itself is never blocked, so nothing white-screens.
- **Third-party cookies blocked** — always, in every tab.
- **HTTPS only** — a plain `http://` navigation is upgraded to `https://` and reloaded.
- **No local file access, no content access, no script popups, no saved form data, no mixed
  content**, and **Google Safe Browsing** for phishing and malware on API 26+.
- **Private tabs** additionally write no site storage and keep nothing in the cache.

Because these are baked in, they are also the reason a few sites will misbehave: a login that
needs a third-party cookie, or a site that only serves `http`, may refuse to work. That is the
trade-off for having protection on by default.

## Known limits

- **Private tabs** — a private tab writes no site storage (`domStorageEnabled` off), blocks
  third-party cookies (that setting *is* per-WebView) and never touches the disk cache. When the
  last private tab closes, all cookies are wiped. Android has one cookie jar for the whole app,
  so that wipe also signs you out of normal tabs — the dialog says so before you open one.
  The homepage in a private tab shows a fresh install, because it has no storage to read.
- No ad-blocking, no reader mode, no downloads manager yet.
- It is WebView with a shell around it, not a new engine.
