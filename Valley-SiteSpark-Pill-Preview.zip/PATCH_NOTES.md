# Valley patch notes

## What changed

- The floating pill's search action now uses a native implementation of the homepage's smart router instead of a simplified URL-or-Brave decision.
- Preserves direct URLs and explicit navigation commands (`open`, `go to`, `visit`, `launch`).
- Adds typo-tolerant matching for known sites when navigating by name.
- Routes supported site-named searches (for example, `price of OnePlus Nord CE 5 on Flipkart`) to that site's search page when smart search is enabled.
- Reads `hp.smart` on the Valley homepage or `ulaa-smart` on a page where Site Spark has saved it. If neither exists, it uses the app-level preference (default on).
- The Smart Search controls now update the app-level preference as well as Site Spark's page-level flag.

## Not claimed

This patch has not been built into an APK in this environment. It has not changed Chromium/WebView itself. The native blur still depends on Valley's existing PixelCopy-based backdrop capture, and may behave differently across Android versions/devices. Run the repository's GitHub Actions build before installing it.
