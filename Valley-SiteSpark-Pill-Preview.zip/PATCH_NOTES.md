# Valley Site Spark pill final preview

- Keeps the existing Valley Android project and home page.
- Uses a separate application ID (`ai.valley.browser.preview`) so the preview can coexist with the installed original app.
- Reduces the expanded toolbar pill scaling from 1.3x to 1.08x, and slightly tightens the control dimensions to reduce crowding.
- Keeps the existing toolbar interaction code, long-press orb, and controls.

This is source code, not a prebuilt APK. The GitHub Actions build and on-device behaviour must still be verified after uploading.
