# Valley history integration patch

- Records normal-tab page visits in Android SharedPreferences when navigation finishes.
- Records searches submitted through the native URL/search pill.
- Syncs native search/page history into the homepage's existing `hp.searches` and `hp.opened` lists when the Valley homepage loads.
- Connects homepage add/remove/clear actions to native history storage through a JavaScript bridge exposed only while the trusted Valley homepage is loaded.
- Private-tab visits and searches are excluded.
- History is capped at 200 entries per list and deduplicated.

Build/test status: source patch prepared; Gradle build and on-device runtime test have not been run in this environment.
