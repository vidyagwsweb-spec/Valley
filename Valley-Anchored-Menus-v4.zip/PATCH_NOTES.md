# Valley refinement patch v3

- Corrected the compile-fix source inherited from v2.
- Anchored toolbar menus near the right-side menu button and capped their height with internal scrolling.
- Kept the long-press orb stationary where the pill was; the tools menu expands from that point. Added Hide/Show Address Bar control.
- Improved tab overview count-pill width and made the count pill open tab actions. The left control shows a plus in overview mode.
- Changed tab overview to two horizontally scrollable rows with about 2.5 cards visible per row.
- Tab previews now show the top of the page at useful scale rather than shrinking the entire page.
- Added responsive homepage spacing and focus-state refinements.

This is a source patch; it has not been compiled on an Android SDK in this environment. GitHub Actions must confirm the APK build.
