# Valley UI correction pass

Based on the uploaded Valley-SiteSpark-Polished-v6 project and retaining the existing homepage, SiteSpark script, Kotlin app shell, and prior features.

## Changes in this pass
- Centered the address pill as a symmetric toolbar group and centered its label between equal-width inner controls.
- Restored horizontal address scrolling and edge fading, including the placeholder; the placeholder remains fully opaque.
- Made the minimized pill genuinely compact and removed hidden reader/reload slots from its layout.
- Applied blur to the captured page image behind the toolbar so the glass effect does not depend solely on WebView backdrop-filter support.
- Disabled the orb in tab-overview mode; long-pressing overview controls no longer opens page tools.
- Made the overview left `+` create a new tab directly; the count pill is display-only; `...` opens tab actions.
- Anchored Back/Forward and settings panels to their actual source buttons using measured positions, and clamped their horizontal placement.
- Limited scrollable menu panels to about seven compact rows and retained top/bottom edge fades.

## Verification limits
- The toolbar JavaScript passes `node --check`.
- Android build was not run because Gradle is not installed in this environment. These changes have not been device-tested; confirm them with the GitHub Actions APK before treating the UI behavior as verified.


## Follow-up menu sizing correction
- Reduced the HTML toolbar menu width from 270px to 220px to remove the excessive unused right-side area.
- Increased menu panel height to allow about seven compact option rows before the top/bottom fade, and reset menu scroll to the first row every time it opens.
- Reduced native popup width to 240dp and set a seven-row height cap with vertical fading edges.
- This is a source patch only; Android build and device behavior still require GitHub Actions verification.
