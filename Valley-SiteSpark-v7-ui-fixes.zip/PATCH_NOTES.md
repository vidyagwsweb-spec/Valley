Valley SiteSpark v6 follow-up UI patch

Changes in this source revision:
- Fixes count/overview toolbar styling so the tab-count pill is compact and legible, and changes the left control to a plus while in overview mode.
- Repositions toolbar HTML panels according to the button that opened them; Back/Forward panel opens from the left navigation control instead of defaulting to the right.
- Caps HTML and native menu height to about seven compact rows and enables vertical fading edges for native scrolling menus.
- Reduces menu row spacing while retaining the existing translucent glass/backdrop styling and original homepage assets.

Verification: JavaScript syntax and the included toolbar check are run separately. Android compilation and on-device behavior have not been verified in this environment.
